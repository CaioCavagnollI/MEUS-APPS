"use client"

import { useState } from "react"
import { AppShell } from "@/components/layout/app-shell"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  BookOpen,
  ExternalLink,
  FileText,
  GraduationCap,
} from "lucide-react"

const MOCK_PAPERS = [
  {
    id: "1",
    source: "pubmed" as const,
    title: "Effects of Undulating Periodization on Muscle Hypertrophy: A Systematic Review",
    authors: [{ name: "Schoenfeld BJ" }, { name: "Grgic J" }],
    journal: "J Strength Cond Res",
    year: 2024,
    doi: "10.1519/JSC.0000000001234",
    oaStatus: "oa" as const,
    abstract:
      "This systematic review examines the effects of undulating periodization models on muscle hypertrophy outcomes compared to linear periodization...",
  },
  {
    id: "2",
    source: "crossref" as const,
    title: "Resistance Training Volume and Hypertrophy: A Meta-Analysis",
    authors: [{ name: "Krieger JW" }],
    journal: "Sports Medicine",
    year: 2023,
    doi: "10.1007/s40279-023-5678",
    oaStatus: "closed" as const,
    abstract:
      "This meta-analysis quantifies the dose-response relationship between weekly resistance training volume and muscle hypertrophy...",
  },
  {
    id: "3",
    source: "openalex" as const,
    title: "Muscle Activation Patterns in Machine vs Free Weight Exercises",
    authors: [{ name: "Schwanbeck SR" }, { name: "Chilibeck PD" }],
    journal: "J Sports Sciences",
    year: 2025,
    doi: "10.1080/02640414.2025.4321",
    oaStatus: "oa" as const,
    abstract:
      "This study compared EMG muscle activation patterns between machine-based and free weight resistance exercises...",
  },
]

const REF_STYLES = ["ABNT", "APA 7", "Vancouver", "BibTeX", "RIS"]

export default function AcademicoPage() {
  const [query, setQuery] = useState("")
  const [searching, setSearching] = useState(false)
  const [results, setResults] = useState(MOCK_PAPERS)

  function handleSearch() {
    if (!query.trim()) return
    setSearching(true)
    setTimeout(() => {
      setResults(MOCK_PAPERS)
      setSearching(false)
    }, 600)
  }

  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Modulo Academico</h1>
          <p className="text-muted-foreground">
            Busca em PubMed, Crossref e OpenAlex. Formatacao de referencias
            integrada.
          </p>
          <div className="mt-2 flex gap-2">
            <Badge className="bg-primary/10 text-primary border-primary/20">
              Web Permitido
            </Badge>
            <Badge className="bg-secondary text-secondary-foreground border-border">
              Dedup Automatico
            </Badge>
          </div>
        </div>

        <Tabs defaultValue="search" className="w-full">
          <TabsList>
            <TabsTrigger value="search" className="gap-1.5">
              <Search className="size-3.5" />
              Busca
            </TabsTrigger>
            <TabsTrigger value="references" className="gap-1.5">
              <FileText className="size-3.5" />
              Referencias
            </TabsTrigger>
            <TabsTrigger value="support" className="gap-1.5">
              <GraduationCap className="size-3.5" />
              Apoio Academico
            </TabsTrigger>
          </TabsList>

          <TabsContent value="search" className="mt-6 space-y-4">
            <div className="flex gap-2">
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ex: periodizacao ondulada hipertrofia"
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                className="flex-1"
              />
              <Button onClick={handleSearch} disabled={searching}>
                <Search className="size-4" />
                {searching ? "Buscando..." : "Buscar"}
              </Button>
            </div>

            <div className="space-y-3">
              {results.map((paper) => (
                <Card key={paper.id} className="transition-colors hover:border-primary/20">
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-start justify-between gap-4">
                      <div className="space-y-1">
                        <h3 className="text-sm font-semibold leading-snug">
                          {paper.title}
                        </h3>
                        <p className="text-xs text-muted-foreground">
                          {paper.authors.map((a) => a.name).join(", ")} —{" "}
                          {paper.journal}, {paper.year}
                        </p>
                      </div>
                      <div className="flex shrink-0 gap-1.5">
                        <Badge
                          variant="outline"
                          className="text-[10px] border-border"
                        >
                          {paper.source}
                        </Badge>
                        <Badge
                          className={
                            paper.oaStatus === "oa"
                              ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-[10px]"
                              : "bg-secondary text-muted-foreground border-border text-[10px]"
                          }
                        >
                          {paper.oaStatus === "oa" ? "Open Access" : "Closed"}
                        </Badge>
                      </div>
                    </div>

                    {paper.abstract && (
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        {paper.abstract}
                      </p>
                    )}

                    <div className="flex items-center gap-3 border-t border-border pt-3">
                      <code className="text-[10px] text-muted-foreground">
                        {paper.doi}
                      </code>
                      <button className="ml-auto flex items-center gap-1 text-xs text-primary hover:underline">
                        <ExternalLink className="size-3" />
                        Abrir
                      </button>
                      <button className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
                        <BookOpen className="size-3" />
                        Salvar
                      </button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="references" className="mt-6 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Formatacao de Referencias</CardTitle>
                <CardDescription>
                  Gere referencias nos estilos ABNT, APA 7, Vancouver, BibTeX e
                  RIS a partir de DOI ou PMID.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input placeholder="DOI ou PMID..." className="flex-1" />
                  <Button variant="outline">Formatar</Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {REF_STYLES.map((style) => (
                    <Badge
                      key={style}
                      variant="outline"
                      className="cursor-pointer border-border text-muted-foreground hover:border-primary/30 hover:text-primary"
                    >
                      {style}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="support" className="mt-6 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Apoio Academico</CardTitle>
                <CardDescription>
                  Pergunte com base em artigos cientificos. Busca em bases
                  externas permitida neste modulo.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2">
                  <Input
                    placeholder="Ex: Quais as evidencias sobre treinamento resistido e diabetes tipo 2?"
                    className="flex-1"
                  />
                  <Button>
                    <GraduationCap className="size-4" />
                    Perguntar
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppShell>
  )
}
