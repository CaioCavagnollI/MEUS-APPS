import { AppShell } from "@/components/layout/app-shell"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Users,
  Database,
  FileText,
  Shield,
  BarChart3,
  Upload,
  Settings,
  AlertTriangle,
} from "lucide-react"

const ADMIN_SECTIONS = [
  {
    title: "Usuarios",
    description: "Gerenciar profiles, roles e planos",
    icon: Users,
    count: "1.247",
    href: "/admin/users",
  },
  {
    title: "Fontes & RAG",
    description: "Documentos, chunks, ingestion jobs",
    icon: Database,
    count: "342",
    href: "/admin/sources",
  },
  {
    title: "Upload Center",
    description: "Presign, commit, ingest, tag",
    icon: Upload,
    count: "89",
    href: "/admin/uploads",
  },
  {
    title: "AI Logs",
    description: "Historico de interacoes da IA",
    icon: FileText,
    count: "15.4k",
    href: "/admin/ai-logs",
  },
  {
    title: "Scanner Logs",
    description: "Audit trail de scans",
    icon: Shield,
    count: "3.2k",
    href: "/admin/scanner-logs",
  },
  {
    title: "Editorial",
    description: "Submissions, reviews, entregas",
    icon: FileText,
    count: "67",
    href: "/admin/editorial",
  },
]

const RECENT_LOGS = [
  {
    type: "auth",
    message: "Login: admin@fitversum.com",
    time: "1min",
    level: "info",
  },
  {
    type: "scanner",
    message: "scan_abc123: FALLBACK (needs_disambiguation)",
    time: "5min",
    level: "warn",
  },
  {
    type: "ai",
    message: "rag_gate_failed: query 'suplementacao creatina'",
    time: "12min",
    level: "warn",
  },
  {
    type: "billing",
    message: "Stripe webhook: subscription.updated (sub_xyz)",
    time: "1h",
    level: "info",
  },
  {
    type: "ingestion",
    message: "job_001: document indexed (342 chunks)",
    time: "2h",
    level: "info",
  },
]

export default function AdminPage() {
  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold">Admin</h1>
            <p className="text-muted-foreground">
              Governanca, fontes, usuarios, logs e metricas do sistema.
            </p>
          </div>
          <Badge className="bg-destructive/10 text-destructive border-destructive/20">
            <Shield className="mr-1 size-3" />
            role=admin
          </Badge>
        </div>

        {/* Admin modules grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {ADMIN_SECTIONS.map((section) => {
            const Icon = section.icon
            return (
              <Card
                key={section.title}
                className="group transition-colors hover:border-primary/30 cursor-pointer"
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="rounded-lg bg-primary/10 p-2">
                      <Icon className="size-4 text-primary" />
                    </div>
                    <span className="text-xl font-bold text-primary">
                      {section.count}
                    </span>
                  </div>
                  <h3 className="mt-3 font-semibold text-sm">
                    {section.title}
                  </h3>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {section.description}
                  </p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Governance Status + Recent Logs */}
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <BarChart3 className="size-4 text-primary" />
                Metricas do Sistema
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { label: "RAG Gate Pass Rate", value: "67%", target: "≥60%" },
                { label: "Scanner Top-1 Accuracy", value: "74%", target: "≥70%" },
                { label: "Scanner p95 Latency", value: "1.8s", target: "≤2.5s" },
                { label: "Uptime", value: "99.9%", target: "≥99.5%" },
              ].map((metric) => (
                <div
                  key={metric.label}
                  className="flex items-center justify-between rounded-lg border border-border p-3"
                >
                  <span className="text-sm">{metric.label}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-mono font-semibold">
                      {metric.value}
                    </span>
                    <Badge
                      variant="outline"
                      className="text-[10px] border-border text-muted-foreground"
                    >
                      target: {metric.target}
                    </Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <AlertTriangle className="size-4 text-primary" />
                Logs Recentes
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {RECENT_LOGS.map((log, i) => (
                <div
                  key={i}
                  className="flex items-start gap-3 rounded-lg border border-border p-3"
                >
                  <Badge
                    className={`text-[10px] shrink-0 ${
                      log.level === "warn"
                        ? "bg-primary/10 text-primary border-primary/20"
                        : "bg-secondary text-secondary-foreground border-border"
                    }`}
                  >
                    {log.type}
                  </Badge>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-mono text-muted-foreground truncate">
                      {log.message}
                    </p>
                  </div>
                  <span className="text-[10px] text-muted-foreground shrink-0">
                    {log.time}
                  </span>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Quick actions */}
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm">
            <Settings className="size-4" />
            Configuracoes
          </Button>
          <Button variant="outline" size="sm">
            <Upload className="size-4" />
            Upload Center
          </Button>
          <Button variant="outline" size="sm">
            <Database className="size-4" />
            Reindex RAG
          </Button>
        </div>
      </div>
    </AppShell>
  )
}
