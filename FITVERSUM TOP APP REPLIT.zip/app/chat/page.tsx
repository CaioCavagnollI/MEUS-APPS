"use client"

import { useState } from "react"
import { AppShell } from "@/components/layout/app-shell"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Send, ShieldCheck, BookOpen, AlertTriangle } from "lucide-react"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  sources?: {
    citationId: string
    title: string
    locator?: string
    quote?: string
  }[]
  safety?: { ragUsed: boolean; blocked: boolean; reason?: string }
}

const DEMO_MESSAGES: Message[] = [
  {
    id: "1",
    role: "user",
    content: "Qual a evidencia sobre periodizacao ondulada para hipertrofia?",
  },
  {
    id: "2",
    role: "assistant",
    content:
      "A periodizacao ondulada diaria (DUP) tem mostrado resultados equivalentes ou superiores a periodizacao linear para hipertrofia em individuos treinados. Estudos recentes indicam que a variacao sistematica de volume e intensidade dentro da mesma semana pode otimizar a resposta adaptativa muscular, especialmente quando combinada com progressao de carga adequada.",
    sources: [
      {
        citationId: "cit_a1b2c3",
        title: "Periodization Strategies for Hypertrophy — Schoenfeld et al.",
        locator: "p. 45-52",
        quote:
          "DUP resulted in significantly greater increases in lean body mass compared to linear periodization...",
      },
      {
        citationId: "cit_d4e5f6",
        title: "Resistance Training Volume and Hypertrophy — Krieger, 2020",
        locator: "Table 3",
      },
    ],
    safety: { ragUsed: true, blocked: false },
  },
]

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>(DEMO_MESSAGES)
  const [input, setInput] = useState("")

  function handleSend() {
    if (!input.trim()) return
    const userMsg: Message = {
      id: `msg_${Date.now()}`,
      role: "user",
      content: input,
    }
    const botMsg: Message = {
      id: `msg_${Date.now() + 1}`,
      role: "assistant",
      content:
        "Nao encontrei base suficiente nas fontes aprovadas para responder com seguranca. Considere refinar sua pergunta ou consultar o modulo academico para busca em bases externas (PubMed, Crossref, OpenAlex).",
      safety: { ragUsed: true, blocked: true, reason: "rag_gate_failed" },
    }
    setMessages([...messages, userMsg, botMsg])
    setInput("")
  }

  return (
    <AppShell>
      <div className="flex h-[calc(100vh-140px)] flex-col">
        {/* Header */}
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold">Fitversum IA</h1>
            <p className="text-sm text-muted-foreground">
              Chat com citacoes cientificas — RAG fechado
            </p>
          </div>
          <div className="flex gap-2">
            <Badge className="bg-primary/10 text-primary border-primary/20">
              <ShieldCheck className="mr-1 size-3" />
              RAG Fechado
            </Badge>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-2">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[80%] rounded-xl p-4 ${
                  msg.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-card border border-border"
                }`}
              >
                <p className="text-sm leading-relaxed">{msg.content}</p>

                {/* Safety warning */}
                {msg.safety?.blocked && (
                  <div className="mt-3 flex items-start gap-2 rounded-lg bg-destructive/10 p-2.5">
                    <AlertTriangle className="size-4 text-destructive shrink-0 mt-0.5" />
                    <p className="text-xs text-destructive">
                      Fallback: base insuficiente. Razao: {msg.safety.reason}
                    </p>
                  </div>
                )}

                {/* Citations */}
                {msg.sources && msg.sources.length > 0 && (
                  <div className="mt-3 space-y-2 border-t border-border/50 pt-3">
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <BookOpen className="size-3" />
                      <span>Fontes ({msg.sources.length})</span>
                    </div>
                    {msg.sources.map((src) => (
                      <div
                        key={src.citationId}
                        className="rounded-lg border border-border/50 bg-secondary/30 p-2.5"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <span className="text-xs font-medium">
                            {src.title}
                          </span>
                          <code className="text-[10px] text-muted-foreground shrink-0">
                            {src.citationId}
                          </code>
                        </div>
                        {src.locator && (
                          <div className="mt-1 text-[10px] text-muted-foreground">
                            {src.locator}
                          </div>
                        )}
                        {src.quote && (
                          <p className="mt-1.5 text-xs text-muted-foreground italic">
                            {`"${src.quote}"`}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Input */}
        <div className="mt-4 flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Pergunte algo baseado em ciencia..."
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            className="flex-1"
          />
          <Button onClick={handleSend} size="icon" disabled={!input.trim()}>
            <Send className="size-4" />
            <span className="sr-only">Enviar mensagem</span>
          </Button>
        </div>

        {/* Quota info */}
        <Card className="mt-3">
          <CardContent className="flex items-center justify-between p-3">
            <span className="text-xs text-muted-foreground">
              Quota de mensagens
            </span>
            <div className="flex items-center gap-2">
              <div className="h-1.5 w-24 rounded-full bg-secondary">
                <div
                  className="h-full rounded-full bg-primary"
                  style={{ width: "47%" }}
                />
              </div>
              <span className="text-xs text-muted-foreground">47/100</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  )
}
