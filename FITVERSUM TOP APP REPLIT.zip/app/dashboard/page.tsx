import { AppShell } from "@/components/layout/app-shell"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  ScanLine,
  MessageSquare,
  Dumbbell,
  BookOpen,
  TrendingUp,
  ShieldCheck,
} from "lucide-react"
import Link from "next/link"

const QUICK_ACTIONS = [
  {
    href: "/chat",
    icon: MessageSquare,
    title: "Fitversum IA",
    description: "Chat com citacoes cientificas",
    badge: "RAG Fechado",
  },
  {
    href: "/scanner",
    icon: ScanLine,
    title: "FitScanner",
    description: "Reconhecimento de equipamento",
    badge: "P0",
  },
  {
    href: "/academico",
    icon: BookOpen,
    title: "Academico",
    description: "Busca PubMed, Crossref, OpenAlex",
    badge: "Web Permitido",
  },
  {
    href: "/loja",
    icon: Dumbbell,
    title: "Loja",
    description: "Downloads protegidos e e-books",
    badge: "Publishing",
  },
]

const RECENT_ACTIVITY = [
  { type: "scan", text: "Scanner: Smith Machine identificada", time: "2min" },
  { type: "chat", text: "IA: Consulta sobre hipertrofia", time: "15min" },
  { type: "workout", text: "Treino gerado: Push/Pull/Legs", time: "1h" },
  { type: "academic", text: "Busca: periodizacao ondulada", time: "3h" },
]

export default function DashboardPage() {
  return (
    <AppShell>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">
            Bem-vindo ao Fitversum Lab. Acesse suas ferramentas abaixo.
          </p>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {[
            { label: "Scans realizados", value: "12", icon: ScanLine },
            { label: "Mensagens IA", value: "47", icon: MessageSquare },
            { label: "Treinos gerados", value: "8", icon: Dumbbell },
            { label: "Citacoes", value: "156", icon: ShieldCheck },
          ].map((stat) => {
            const Icon = stat.icon
            return (
              <Card key={stat.label}>
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="rounded-lg bg-primary/10 p-2.5">
                    <Icon className="size-5 text-primary" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">{stat.value}</div>
                    <div className="text-xs text-muted-foreground">
                      {stat.label}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Quick actions */}
        <div>
          <h2 className="mb-4 text-lg font-semibold">Acoes rapidas</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {QUICK_ACTIONS.map((action) => {
              const Icon = action.icon
              return (
                <Link key={action.href} href={action.href}>
                  <Card className="h-full transition-colors hover:border-primary/30 cursor-pointer">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="rounded-lg bg-primary/10 p-2">
                          <Icon className="size-4 text-primary" />
                        </div>
                        <Badge
                          variant="outline"
                          className="text-[10px] border-border text-muted-foreground"
                        >
                          {action.badge}
                        </Badge>
                      </div>
                      <h3 className="mt-3 font-semibold text-sm">
                        {action.title}
                      </h3>
                      <p className="mt-1 text-xs text-muted-foreground">
                        {action.description}
                      </p>
                    </CardContent>
                  </Card>
                </Link>
              )
            })}
          </div>
        </div>

        {/* Activity + Governance */}
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Atividade Recente</CardTitle>
              <CardDescription>Ultimas interacoes no sistema</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {RECENT_ACTIVITY.map((item, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between rounded-lg border border-border p-3"
                >
                  <span className="text-sm">{item.text}</span>
                  <span className="text-xs text-muted-foreground shrink-0 ml-2">
                    {item.time}
                  </span>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Governanca</CardTitle>
              <CardDescription>
                Status dos sistemas de seguranca
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { label: "RAG Core", status: "Ativo", ok: true },
                { label: "Auditoria", status: "Ativo", ok: true },
                { label: "RLS/Isolamento", status: "Ativo", ok: true },
                { label: "Rate Limiting", status: "Configurado", ok: true },
              ].map((item) => (
                <div
                  key={item.label}
                  className="flex items-center justify-between rounded-lg border border-border p-3"
                >
                  <div className="flex items-center gap-2">
                    <TrendingUp className="size-4 text-primary" />
                    <span className="text-sm">{item.label}</span>
                  </div>
                  <Badge
                    className={
                      item.ok
                        ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                        : "bg-destructive/10 text-destructive border-destructive/20"
                    }
                  >
                    {item.status}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  )
}
