import { AppShell } from "@/components/layout/app-shell"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, Share2, BookOpen } from "lucide-react"

const MOCK_POSTS = [
  {
    id: "1",
    author: "Dr. Marcos Silva",
    role: "professional",
    title: "Periodizacao Ondulada: Evidencias Atualizadas",
    excerpt:
      "Um resumo atualizado sobre os achados mais recentes em periodizacao ondulada para hipertrofia, com foco em volume e frequencia otimos.",
    tags: ["periodizacao", "hipertrofia", "evidencias"],
    likes: 42,
    shares: 8,
    date: "27 Fev 2026",
  },
  {
    id: "2",
    author: "Fitversum Lab",
    role: "admin",
    title: "Novo: FitScanner com Desambiguacao por Chips",
    excerpt:
      "O scanner agora retorna candidatos quando a confianca entre equipamentos e proxima, permitindo selecao manual antes de prosseguir.",
    tags: ["scanner", "update", "P0"],
    likes: 89,
    shares: 23,
    date: "26 Fev 2026",
  },
  {
    id: "3",
    author: "Profa. Ana Costa",
    role: "professional",
    title: "Treinamento Resistido e Saude Metabolica",
    excerpt:
      "Revisao sistematica sobre os efeitos do treinamento resistido em marcadores metabolicos: glicemia, perfil lipidico e sensibilidade a insulina.",
    tags: ["metabolismo", "revisao-sistematica", "saude"],
    likes: 31,
    shares: 12,
    date: "25 Fev 2026",
  },
]

export default function FeedPage() {
  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Feed Tecnico</h1>
          <p className="text-muted-foreground">
            Conteudo cientifico curado. Sem comentarios — apenas curtir e
            compartilhar.
          </p>
        </div>

        <div className="space-y-4">
          {MOCK_POSTS.map((post) => (
            <Card key={post.id} className="transition-colors hover:border-primary/20">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                        <span className="text-xs font-bold text-primary">
                          {post.author[0]}
                        </span>
                      </div>
                      <div>
                        <span className="text-sm font-medium">
                          {post.author}
                        </span>
                        <span className="ml-2 text-xs text-muted-foreground">
                          {post.date}
                        </span>
                      </div>
                    </div>
                    <CardTitle className="mt-3 text-base">
                      {post.title}
                    </CardTitle>
                  </div>
                  <Badge
                    variant="outline"
                    className="shrink-0 border-border text-muted-foreground text-[10px]"
                  >
                    {post.role}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {post.excerpt}
                </p>

                <div className="flex flex-wrap gap-2">
                  {post.tags.map((tag) => (
                    <Badge
                      key={tag}
                      variant="outline"
                      className="text-[10px] border-border text-muted-foreground"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>

                <div className="flex items-center gap-4 border-t border-border pt-3">
                  <button className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors">
                    <Heart className="size-4" />
                    <span>{post.likes}</span>
                  </button>
                  <button className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors">
                    <Share2 className="size-4" />
                    <span>{post.shares}</span>
                  </button>
                  <button className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors ml-auto">
                    <BookOpen className="size-4" />
                    <span>Ler mais</span>
                  </button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppShell>
  )
}
