import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CodeBlock } from "@/components/integration/code-block"
import {
  EMBED_IFRAME,
  SDK_EXAMPLE,
  WEBHOOK_DOC,
  SECURITY_NOTES,
} from "@/lib/integration-snippets"
import { Shield, Code2, Webhook } from "lucide-react"

export default function IntegrationPage() {
  return (
    <main className="mx-auto max-w-5xl space-y-6 p-6">
      <header className="space-y-3">
        <h1 className="text-2xl font-bold">Integracoes do FitScanner</h1>
        <p className="text-muted-foreground leading-relaxed">
          Embed (IFrame), JS SDK e Webhooks. Projetado para HTTPS, permissoes
          de camera e auditabilidade.
        </p>
        <div className="flex flex-wrap gap-2">
          <Badge className="bg-primary/10 text-primary border-primary/20">
            HTTPS
          </Badge>
          <Badge className="bg-secondary text-secondary-foreground border-border">
            Camera Permissions
          </Badge>
          <Badge className="bg-secondary text-secondary-foreground border-border">
            HMAC Webhooks
          </Badge>
          <Badge className="bg-secondary text-secondary-foreground border-border">
            Audit Trail
          </Badge>
        </div>
      </header>

      <Tabs defaultValue="embed" className="w-full">
        <TabsList>
          <TabsTrigger value="embed" className="gap-1.5">
            <Code2 className="size-3.5" />
            Embed
          </TabsTrigger>
          <TabsTrigger value="sdk" className="gap-1.5">
            <Code2 className="size-3.5" />
            JS SDK
          </TabsTrigger>
          <TabsTrigger value="webhooks" className="gap-1.5">
            <Webhook className="size-3.5" />
            Webhooks
          </TabsTrigger>
        </TabsList>

        <TabsContent value="embed" className="mt-6 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Embed (IFrame)</CardTitle>
              <CardDescription>
                A forma mais rapida. Ideal para landing pages, LMS e portais.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <CodeBlock code={EMBED_IFRAME} label="HTML" />
              <ul className="list-disc pl-5 text-sm text-muted-foreground space-y-1.5 leading-relaxed">
                <li>Producao: HTTPS obrigatorio para camera.</li>
                <li>Use token curto e allowlist de origins.</li>
                <li>Recomenda-se sandbox de iframe quando aplicavel.</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sdk" className="mt-6 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>JS SDK</CardTitle>
              <CardDescription>
                Integracao profunda: eventos, controle e persistencia no seu
                sistema.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <CodeBlock code={SDK_EXAMPLE} label="JavaScript" />
              <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                <div>
                  <span className="font-mono text-xs">onScanStart</span> —
                  Inicio do scan
                </div>
                <div>
                  <span className="font-mono text-xs">onScanResult</span> —
                  Resultado disponivel
                </div>
                <div>
                  <span className="font-mono text-xs">onScanError</span> — Erro
                  no scanner
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="webhooks" className="mt-6 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Webhooks</CardTitle>
              <CardDescription>
                Sincronize resultados com banco/CRM em tempo real.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <CodeBlock code={WEBHOOK_DOC} label="HTTP" />
              <div className="rounded-xl border border-border p-4">
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <Shield className="size-4 text-primary" />
                  Notas de seguranca
                </div>
                <ul className="mt-3 list-disc pl-5 text-sm text-muted-foreground space-y-1.5 leading-relaxed">
                  {SECURITY_NOTES.map((x) => (
                    <li key={x}>{x}</li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </main>
  )
}
