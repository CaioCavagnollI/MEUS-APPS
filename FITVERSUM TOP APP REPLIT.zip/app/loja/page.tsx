import { AppShell } from "@/components/layout/app-shell"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ShoppingBag, Download, Star } from "lucide-react"
import Link from "next/link"

const MOCK_PRODUCTS = [
  {
    slug: "guia-hipertrofia-avancada",
    title: "Guia de Hipertrofia Avancada",
    author: "Dr. Marcos Silva",
    price: "R$ 97,00",
    type: "E-book",
    tags: ["hipertrofia", "avancado", "evidencias"],
    rating: 4.8,
    downloads: 1243,
  },
  {
    slug: "periodizacao-ondulada-masterclass",
    title: "Periodizacao Ondulada — Masterclass",
    author: "Profa. Ana Costa",
    price: "R$ 147,00",
    type: "Curso",
    tags: ["periodizacao", "DUP", "curso"],
    rating: 4.9,
    downloads: 876,
  },
  {
    slug: "anatomia-funcional-musculacao",
    title: "Anatomia Funcional para Musculacao",
    author: "Fitversum Lab",
    price: "R$ 67,00",
    type: "E-book",
    tags: ["anatomia", "biomecânica", "fundamentos"],
    rating: 4.7,
    downloads: 2134,
  },
  {
    slug: "scanner-pro-templates",
    title: "Templates Pro para FitScanner",
    author: "Fitversum Lab",
    price: "Gratis",
    type: "Template",
    tags: ["scanner", "templates", "gratis"],
    rating: 4.5,
    downloads: 3421,
  },
  {
    slug: "treinamento-resistido-metabolismo",
    title: "Treinamento Resistido e Metabolismo",
    author: "Dr. Paulo Mendes",
    price: "R$ 87,00",
    type: "E-book",
    tags: ["metabolismo", "saude", "evidencias"],
    rating: 4.6,
    downloads: 654,
  },
  {
    slug: "prescricao-auditavel-guia",
    title: "Prescricao Auditavel — Guia Completo",
    author: "Fitversum Lab",
    price: "R$ 127,00",
    type: "E-book + Templates",
    tags: ["prescricao", "auditoria", "profissional"],
    rating: 4.9,
    downloads: 987,
  },
]

export default function LojaPage() {
  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold">Loja</h1>
            <p className="text-muted-foreground">
              Downloads protegidos, e-books, cursos e templates com entitlements.
            </p>
          </div>
          <Button variant="outline" size="sm" asChild>
            <Link href="/minha-biblioteca">
              <Download className="size-4" />
              Minha Biblioteca
            </Link>
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {MOCK_PRODUCTS.map((product) => (
            <Card
              key={product.slug}
              className="group transition-colors hover:border-primary/30"
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <Badge
                    variant="outline"
                    className="text-[10px] border-border text-muted-foreground"
                  >
                    {product.type}
                  </Badge>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Star className="size-3 text-primary fill-primary" />
                    {product.rating}
                  </div>
                </div>
                <CardTitle className="text-sm mt-2">{product.title}</CardTitle>
                <CardDescription>{product.author}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex flex-wrap gap-1.5">
                  {product.tags.map((tag) => (
                    <Badge
                      key={tag}
                      variant="outline"
                      className="text-[10px] border-border text-muted-foreground"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>

                <div className="flex items-center justify-between border-t border-border pt-3">
                  <span className="font-semibold text-primary">
                    {product.price}
                  </span>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Download className="size-3" />
                    {product.downloads.toLocaleString("pt-BR")}
                  </div>
                </div>

                <Button className="w-full" size="sm">
                  <ShoppingBag className="size-4" />
                  {product.price === "Gratis" ? "Baixar" : "Comprar"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppShell>
  )
}
