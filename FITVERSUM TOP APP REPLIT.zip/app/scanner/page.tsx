"use client"

import dynamic from "next/dynamic"
import { AppShell } from "@/components/layout/app-shell"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"

const ScannerClient = dynamic(
  () => import("@/components/scanner/scanner-client").then((m) => m.ScannerClient),
  { ssr: false }
)

export default function ScannerPage() {
  return (
    <AppShell>
      <Card>
        <CardHeader>
          <CardTitle>FitScanner</CardTitle>
          <CardDescription>
            Reconhecimento de equipamento + exercicios compativeis + musculos + evidencia + audit trail.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScannerClient />
        </CardContent>
      </Card>
    </AppShell>
  )
}
