import { AppShell } from "@/components/layout/app-shell"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Upload, FileText, Image, File } from "lucide-react"

const MOCK_UPLOADS = [
  {
    id: "1",
    name: "anamnese_joao.pdf",
    type: "PDF",
    size: "2.3 MB",
    status: "processed",
    date: "27 Fev 2026",
  },
  {
    id: "2",
    name: "exame_sangue_fev.png",
    type: "Imagem",
    size: "1.1 MB",
    status: "processed",
    date: "25 Fev 2026",
  },
  {
    id: "3",
    name: "historico_academico.pdf",
    type: "PDF",
    size: "4.7 MB",
    status: "pending",
    date: "24 Fev 2026",
  },
]

function FileIcon({ type }: { type: string }) {
  if (type === "Imagem") return <Image className="size-4 text-primary" />
  if (type === "PDF") return <FileText className="size-4 text-primary" />
  return <File className="size-4 text-primary" />
}

export default function UploadsPage() {
  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold">Uploads</h1>
            <p className="text-muted-foreground">
              Envie anamneses, exames e arquivos academicos.
            </p>
          </div>
          <Button>
            <Upload className="size-4" />
            Novo Upload
          </Button>
        </div>

        {/* Upload area */}
        <Card className="border-dashed border-2">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="rounded-full bg-primary/10 p-4">
              <Upload className="size-6 text-primary" />
            </div>
            <p className="mt-4 text-sm text-foreground font-medium">
              Arraste arquivos aqui ou clique para selecionar
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              PDF, PNG, JPG ate 10MB
            </p>
          </CardContent>
        </Card>

        {/* File list */}
        <div>
          <h2 className="mb-3 text-lg font-semibold">Arquivos Recentes</h2>
          <div className="space-y-2">
            {MOCK_UPLOADS.map((file) => (
              <Card key={file.id}>
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="rounded-lg bg-secondary p-2.5">
                    <FileIcon type={file.type} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{file.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {file.type} — {file.size} — {file.date}
                    </p>
                  </div>
                  <Badge
                    className={
                      file.status === "processed"
                        ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                        : "bg-primary/10 text-primary border-primary/20"
                    }
                  >
                    {file.status === "processed" ? "Processado" : "Pendente"}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  )
}
