"use client"

import { type ReactNode, useState } from "react"
import { MobileHeader } from "./top-nav"
import { DesktopSidebar } from "./sidebar"
import { BottomNav } from "./bottom-nav"
import { MobileDrawer } from "./mobile-drawer"

export function AppShell({ children }: { children: ReactNode }) {
  const [drawerOpen, setDrawerOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Desktop sidebar */}
      <DesktopSidebar />

      {/* Mobile header */}
      <MobileHeader />

      {/* Main content - offset for desktop sidebar */}
      <main className="lg:ml-60 min-h-screen pb-20 lg:pb-0">
        <div className="mx-auto max-w-5xl p-4 lg:p-6">{children}</div>
      </main>

      {/* Mobile bottom tab bar */}
      <BottomNav onOpenMore={() => setDrawerOpen(true)} />

      {/* Mobile "more" drawer */}
      <MobileDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)} />
    </div>
  )
}
