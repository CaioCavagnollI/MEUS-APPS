"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  ScanLine,
  MessageSquare,
  ShoppingBag,
  MoreHorizontal,
} from "lucide-react"

const TABS = [
  { href: "/dashboard", label: "Inicio", icon: LayoutDashboard },
  { href: "/scanner", label: "Scanner", icon: ScanLine },
  { href: "/chat", label: "IA", icon: MessageSquare },
  { href: "/loja", label: "Loja", icon: ShoppingBag },
  { href: "#more", label: "Mais", icon: MoreHorizontal },
]

export function BottomNav({ onOpenMore }: { onOpenMore: () => void }) {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-background/95 backdrop-blur-lg safe-area-bottom lg:hidden">
      <div className="flex items-stretch justify-around">
        {TABS.map((tab) => {
          const Icon = tab.icon
          const isActive =
            tab.href !== "#more" &&
            (pathname === tab.href || pathname.startsWith(tab.href + "/"))
          const isMore = tab.href === "#more"

          if (isMore) {
            return (
              <button
                key="more"
                onClick={onOpenMore}
                className="flex flex-1 flex-col items-center gap-0.5 py-2 text-muted-foreground active:text-primary transition-colors"
              >
                <Icon className="size-5" />
                <span className="text-[10px] font-medium">{tab.label}</span>
              </button>
            )
          }

          return (
            <Link
              key={tab.href}
              href={tab.href}
              className={`flex flex-1 flex-col items-center gap-0.5 py-2 transition-colors ${
                isActive
                  ? "text-primary"
                  : "text-muted-foreground active:text-foreground"
              }`}
            >
              <Icon className="size-5" />
              <span className="text-[10px] font-medium">{tab.label}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
