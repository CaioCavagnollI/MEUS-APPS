"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  MessageSquare,
  ScanLine,
  ShoppingBag,
  GraduationCap,
  Plug,
  Shield,
  Rss,
  Upload,
  X,
  ChevronRight,
} from "lucide-react"

const DRAWER_LINKS = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/chat", label: "Fitversum IA", icon: MessageSquare },
  { href: "/scanner", label: "FitScanner", icon: ScanLine },
  { href: "/feed", label: "Feed Tecnico", icon: Rss },
  { href: "/loja", label: "Loja", icon: ShoppingBag },
  { href: "/academico", label: "Academico", icon: GraduationCap },
  { href: "/uploads", label: "Uploads", icon: Upload },
  { href: "/integration", label: "Integracoes", icon: Plug },
  { href: "/admin", label: "Admin", icon: Shield },
]

export function MobileDrawer({
  open,
  onClose,
}: {
  open: boolean
  onClose: () => void
}) {
  const pathname = usePathname()

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 z-[60] bg-background/80 backdrop-blur-sm transition-opacity lg:hidden ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        onClick={onClose}
        aria-hidden
      />

      {/* Drawer from bottom */}
      <div
        className={`fixed inset-x-0 bottom-0 z-[70] max-h-[85vh] overflow-y-auto rounded-t-2xl border-t border-border bg-card transition-transform duration-300 lg:hidden ${
          open ? "translate-y-0" : "translate-y-full"
        }`}
      >
        {/* Handle */}
        <div className="flex items-center justify-between p-4 pb-2">
          <span className="text-sm font-semibold text-foreground">Menu</span>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-muted-foreground hover:bg-secondary active:bg-secondary/70 transition-colors"
            aria-label="Fechar menu"
          >
            <X className="size-5" />
          </button>
        </div>

        <nav className="flex flex-col gap-0.5 px-3 pb-8">
          {DRAWER_LINKS.map((item) => {
            const Icon = item.icon
            const isActive =
              pathname === item.href || pathname.startsWith(item.href + "/")
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={onClose}
                className={`flex items-center gap-3 rounded-xl px-4 py-3 text-sm transition-colors ${
                  isActive
                    ? "bg-primary/10 text-primary font-medium"
                    : "text-foreground active:bg-secondary"
                }`}
              >
                <Icon className="size-5 shrink-0" />
                <span className="flex-1">{item.label}</span>
                <ChevronRight className="size-4 text-muted-foreground" />
              </Link>
            )
          })}
        </nav>

        <div className="px-4 pb-6">
          <div className="rounded-xl bg-secondary/50 p-3">
            <p className="text-xs text-muted-foreground leading-relaxed">
              {"Fitversum Lab — Ciencia & Performance."}
            </p>
          </div>
        </div>
      </div>
    </>
  )
}
