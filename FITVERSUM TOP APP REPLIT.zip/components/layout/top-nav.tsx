"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Badge } from "@/components/ui/badge"
import { Bell } from "lucide-react"

export function MobileHeader() {
  const pathname = usePathname()

  const pageTitle = (() => {
    if (pathname.startsWith("/dashboard")) return "Dashboard"
    if (pathname.startsWith("/chat")) return "Fitversum IA"
    if (pathname.startsWith("/scanner")) return "FitScanner"
    if (pathname.startsWith("/feed")) return "Feed"
    if (pathname.startsWith("/loja")) return "Loja"
    if (pathname.startsWith("/academico")) return "Academico"
    if (pathname.startsWith("/uploads")) return "Uploads"
    if (pathname.startsWith("/integration")) return "Integracoes"
    if (pathname.startsWith("/admin")) return "Admin"
    return "Fitversum Lab"
  })()

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border bg-background/95 backdrop-blur-lg px-4 py-3 lg:hidden">
      <div className="flex items-center gap-2">
        <Link href="/" className="flex items-center gap-2">
          <span className="inline-flex h-7 w-7 items-center justify-center rounded-md bg-primary text-primary-foreground font-bold text-xs">
            FL
          </span>
        </Link>
        <h1 className="text-sm font-semibold text-foreground">{pageTitle}</h1>
      </div>

      <div className="flex items-center gap-2">
        <Badge className="bg-primary/10 text-primary border-primary/20 text-[9px]">
          Premium
        </Badge>
        <button className="relative rounded-lg p-1.5 text-muted-foreground hover:bg-secondary active:bg-secondary/70 transition-colors">
          <Bell className="size-5" />
          <span className="absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full bg-primary" />
        </button>
      </div>
    </header>
  )
}
