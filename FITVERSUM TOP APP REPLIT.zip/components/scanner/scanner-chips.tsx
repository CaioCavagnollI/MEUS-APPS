"use client"

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

type Candidate = { equipId: string; equipmentName: string; confidence: number }

export function ScannerChips(props: {
  title: string
  candidates: Candidate[]
  selectedEquipId: string | null
  onSelect: (equipId: string) => void
}) {
  const { title, candidates, selectedEquipId, onSelect } = props
  if (!candidates?.length) return null

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm">{title}</CardTitle>
        <CardDescription>
          Quando a diferenca de confianca e pequena, escolha o equipamento
          correto antes de prosseguir.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-wrap gap-2">
        {candidates.slice(0, 8).map((c) => {
          const active = c.equipId === selectedEquipId
          return (
            <button
              key={c.equipId}
              onClick={() => onSelect(c.equipId)}
              className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs transition-colors ${
                active
                  ? "border-primary/40 bg-primary/10 text-primary"
                  : "border-border bg-secondary/50 text-muted-foreground hover:text-foreground hover:border-border"
              }`}
            >
              {c.equipmentName}
              <Badge
                variant="secondary"
                className={`text-[10px] ${active ? "bg-primary/20 text-primary" : ""}`}
              >
                {(c.confidence * 100).toFixed(0)}%
              </Badge>
            </button>
          )
        })}
      </CardContent>
    </Card>
  )
}
