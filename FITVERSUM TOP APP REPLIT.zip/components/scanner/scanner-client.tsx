"use client"

import { useMemo, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ScannerUpload } from "./scanner-upload"
import { ScannerChips } from "./scanner-chips"
import { ScannerResult } from "./scanner-result"
import { ScannerMetrics } from "./scanner-metrics"
import { ScanLine, CheckCircle2 } from "lucide-react"

type Candidate = { equipId: string; equipmentName: string; confidence: number }

// Mock scanner API response
function mockScannerResponse(userSelectedEquipId?: string | null) {
  const candidates: Candidate[] = [
    { equipId: "smith_machine", equipmentName: "Smith Machine", confidence: 0.84 },
    { equipId: "chest_press_machine", equipmentName: "Chest Press Machine", confidence: 0.78 },
    { equipId: "cable_crossover", equipmentName: "Cable Crossover", confidence: 0.74 },
    { equipId: "seated_row_machine", equipmentName: "Seated Row Machine", confidence: 0.71 },
  ]

  const deltaMin = 0.10
  const needsDisambig = !userSelectedEquipId && (candidates[0].confidence - candidates[1].confidence) < deltaMin
  const scanId = `scan_${Math.random().toString(36).slice(2, 10)}`

  if (needsDisambig) {
    return {
      status: "FALLBACK",
      scanId,
      message: "Selecione o equipamento sugerido para prosseguir com seguranca.",
      needsDisambiguation: true,
      candidates,
      assumptions: ["Objetivo informado: hypertrophy", "Restricoes: dor lombar aguda"],
      confidenceScore: candidates[0].confidence,
    }
  }

  const selected = userSelectedEquipId
    ? candidates.find((c) => c.equipId === userSelectedEquipId) ?? candidates[0]
    : candidates[0]

  return {
    status: "OK",
    scanId,
    equipmentName: selected.equipmentName,
    equipId: selected.equipId,
    compatibleExercises: [
      "Smith Machine Squat",
      "Smith Machine Bench Press",
      "Smith Machine Row",
      "Smith Machine Shoulder Press",
      "Smith Machine Lunges",
    ],
    muscles: {
      primeMovers: ["Quadriceps", "Pectoralis Major", "Deltoid Anterior"],
      synergists: ["Gluteus Maximus", "Triceps Brachii", "Serratus Anterior"],
      stabilizers: ["Core (Transverse Abdominis)", "Erector Spinae"],
    },
    evidence: {
      citations: [
        {
          citationId: "cit_sm01",
          title: "Biomechanics of the Smith Machine — Cotterman et al.",
          locator: "p. 45-47",
          quote: "The Smith Machine provides a guided bar path that may benefit beginners...",
        },
        {
          citationId: "cit_sm02",
          title: "Muscle Activation Patterns in Machine vs Free Weight — Schwanbeck et al.",
          locator: "Table 2, Fig. 4",
        },
      ],
      snippets: [
        "Evidencia governada (stub). Integrar retrieval por equip_id + goal + constraints.",
      ],
    },
    assumptions: [
      "Objetivo informado: hypertrophy",
      "Restricoes: dor lombar aguda",
      "Nivel: beginner — priorizar estabilidade e ROM controlado.",
    ],
    confidenceScore: selected.confidence,
    candidates,
    quota: { used: 13, limit: null },
  }
}

export function ScannerClient() {
  const [assetId, setAssetId] = useState("asset_demo_001")
  const [constraints, setConstraints] = useState("dor lombar aguda")
  const [goal, setGoal] = useState("hypertrophy")
  const [level, setLevel] = useState<"beginner" | "intermediate" | "advanced">("beginner")

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<Record<string, unknown> | null>(null)
  const [candidates, setCandidates] = useState<Candidate[]>([])
  const [selectedEquipId, setSelectedEquipId] = useState<string | null>(null)

  const hasDisambiguation = useMemo(() => {
    return Boolean(result?.needsDisambiguation) || (Array.isArray(candidates) && candidates.length >= 3)
  }, [result, candidates])

  async function callScanner(userSelectedEquipId?: string | null) {
    setLoading(true)
    setError(null)

    try {
      // Simulate API delay
      await new Promise((r) => setTimeout(r, 800))
      const res = mockScannerResponse(userSelectedEquipId)
      setResult(res)
      const c = Array.isArray(res?.candidates) ? res.candidates : []
      setCandidates(c)
      if (res?.equipId) setSelectedEquipId(res.equipId)
    } catch (e: unknown) {
      const message = e instanceof Error ? e.message : "Erro ao executar scanner"
      setError(message)
    } finally {
      setLoading(false)
    }
  }

  async function onRun() {
    await callScanner(null)
  }

  async function onConfirmSelection() {
    if (!selectedEquipId) return
    await callScanner(selectedEquipId)
  }

  return (
    <div className="space-y-4">
      <ScannerUpload
        assetId={assetId}
        setAssetId={setAssetId}
        constraints={constraints}
        setConstraints={setConstraints}
        goal={goal}
        setGoal={setGoal}
        level={level}
        setLevel={setLevel}
      />

      <div className="flex flex-wrap gap-2">
        <Button onClick={onRun} disabled={loading}>
          <ScanLine className="size-4" />
          {loading ? "Analisando..." : "Executar scanner"}
        </Button>

        {hasDisambiguation && (
          <Button
            variant="outline"
            onClick={onConfirmSelection}
            disabled={loading || !selectedEquipId}
          >
            <CheckCircle2 className="size-4" />
            Confirmar selecao
          </Button>
        )}
      </div>

      {error && (
        <Card>
          <CardContent className="p-4 text-destructive text-sm">
            {error}
          </CardContent>
        </Card>
      )}

      <ScannerMetrics result={result} />

      {hasDisambiguation && (
        <ScannerChips
          title="Selecionar equipamento sugerido"
          candidates={candidates}
          selectedEquipId={selectedEquipId}
          onSelect={setSelectedEquipId}
        />
      )}

      {result && <ScannerResult result={result} />}
    </div>
  )
}
