import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"

export function ScannerEvidence({ result }: { result: Record<string, unknown> }) {
  const evidence = result.evidence as {
    citations?: { citationId: string; title: string; locator?: string; quote?: string }[]
    snippets?: string[]
  } | undefined

  const citations = evidence?.citations ?? []
  const snippets = evidence?.snippets ?? []

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm">Evidencias</CardTitle>
        <CardDescription>
          Citacoes governadas (RAG/curadoria). Sem base → fallback.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {citations.length > 0 ? (
          <div className="space-y-3">
            {citations.slice(0, 8).map((c, i) => (
              <div
                key={c.citationId ?? i}
                className="rounded-xl border border-border p-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-sm font-medium">{c.title}</span>
                  <code className="text-[10px] text-muted-foreground">
                    {c.citationId}
                  </code>
                </div>
                {c.locator && (
                  <div className="mt-1 text-xs text-muted-foreground">
                    {c.locator}
                  </div>
                )}
                {c.quote && (
                  <p className="mt-2 text-sm text-muted-foreground italic">
                    {`"${c.quote}"`}
                  </p>
                )}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">
            Sem citacoes disponiveis.
          </p>
        )}

        {snippets.length > 0 && (
          <div className="rounded-xl border border-border p-3">
            <div className="text-xs font-semibold text-muted-foreground">
              Snippets
            </div>
            <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-muted-foreground">
              {snippets.slice(0, 6).map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ul>
          </div>
        )}

        <details className="rounded-xl border border-border p-3">
          <summary className="cursor-pointer text-xs text-muted-foreground">
            Debug JSON
          </summary>
          <pre className="mt-2 overflow-auto rounded-xl bg-secondary/50 p-3 text-[11px] text-muted-foreground font-mono">
            {JSON.stringify(result, null, 2)}
          </pre>
        </details>
      </CardContent>
    </Card>
  )
}
