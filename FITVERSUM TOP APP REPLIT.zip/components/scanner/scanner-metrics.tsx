import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function ScannerMetrics({ result }: { result: Record<string, unknown> | null }) {
  if (!result) return null

  const quota = result.quota as { used?: number; limit?: number } | undefined

  return (
    <Card>
      <CardContent className="flex flex-wrap items-center gap-4 p-4">
        {result.confidenceScore != null && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Confianca:</span>
            <Badge
              className={
                (result.confidenceScore as number) >= 0.8
                  ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                  : (result.confidenceScore as number) >= 0.6
                  ? "bg-primary/10 text-primary border-primary/20"
                  : "bg-destructive/10 text-destructive border-destructive/20"
              }
            >
              {((result.confidenceScore as number) * 100).toFixed(0)}%
            </Badge>
          </div>
        )}
        {result.status && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Status:</span>
            <Badge
              className={
                result.status === "OK"
                  ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                  : "bg-primary/10 text-primary border-primary/20"
              }
            >
              {result.status as string}
            </Badge>
          </div>
        )}
        {quota && (
          <div className="flex items-center gap-2 ml-auto">
            <span className="text-xs text-muted-foreground">Quota Scanner:</span>
            <span className="text-xs font-mono">
              {quota.used ?? "—"}/{quota.limit ?? "ilimitado"}
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
