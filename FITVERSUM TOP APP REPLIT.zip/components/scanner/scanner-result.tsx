import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { ScannerEvidence } from "./scanner-evidence"

function List({ title, items }: { title: string; items: string[] }) {
  return (
    <div>
      <div className="text-xs font-semibold text-muted-foreground">{title}</div>
      {items?.length ? (
        <ul className="mt-1 list-disc space-y-1 pl-5 text-sm text-muted-foreground">
          {items.map((x, i) => (
            <li key={i}>{x}</li>
          ))}
        </ul>
      ) : (
        <p className="mt-1 text-sm text-muted-foreground">{"—"}</p>
      )}
    </div>
  )
}

export function ScannerResult({ result }: { result: Record<string, unknown> }) {
  const status = (result.status as string) ?? "OK"
  const isFallback = status === "FALLBACK"

  const muscles = result.muscles as {
    primeMovers?: string[]
    synergists?: string[]
    stabilizers?: string[]
  } | undefined

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card className={isFallback ? "border-destructive/30" : ""}>
        <CardHeader>
          <CardTitle className="text-sm">Resultado</CardTitle>
          {isFallback ? (
            <CardDescription className="text-destructive">
              Nao reconhecido com seguranca. Tente outra foto/angulo e boa
              iluminacao.
            </CardDescription>
          ) : (
            <CardDescription>
              Audit trail: scan_id + evidencia + suposicoes.
            </CardDescription>
          )}
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="grid gap-2 text-sm">
            <div>
              <span className="text-muted-foreground">scan_id:</span>{" "}
              <span className="font-mono">{result.scanId as string}</span>
            </div>
            <div>
              <span className="text-muted-foreground">equip_id:</span>{" "}
              <span className="font-mono">
                {(result.equipId as string) ?? "—"}
              </span>
            </div>
            <div>
              <span className="text-muted-foreground">equipment:</span>{" "}
              {(result.equipmentName as string) ?? "—"}
            </div>
            <div>
              <span className="text-muted-foreground">confidence:</span>{" "}
              {typeof result.confidenceScore === "number"
                ? `${((result.confidenceScore as number) * 100).toFixed(0)}%`
                : "—"}
            </div>
          </div>

          <List
            title="Exercicios compativeis"
            items={(result.compatibleExercises as string[]) ?? []}
          />

          <div className="grid gap-3 rounded-xl border border-border p-3">
            <List
              title="Prime movers"
              items={muscles?.primeMovers ?? []}
            />
            <List title="Synergists" items={muscles?.synergists ?? []} />
            <List title="Stabilizers" items={muscles?.stabilizers ?? []} />
          </div>

          <List
            title="Assumptions"
            items={(result.assumptions as string[]) ?? []}
          />
        </CardContent>
      </Card>

      <ScannerEvidence result={result} />
    </div>
  )
}
