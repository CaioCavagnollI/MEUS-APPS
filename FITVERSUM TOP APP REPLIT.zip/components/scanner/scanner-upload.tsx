"use client"

import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

export function ScannerUpload(props: {
  assetId: string
  setAssetId: (v: string) => void
  constraints: string
  setConstraints: (v: string) => void
  goal: string
  setGoal: (v: string) => void
  level: "beginner" | "intermediate" | "advanced"
  setLevel: (v: "beginner" | "intermediate" | "advanced") => void
}) {
  const {
    assetId,
    setAssetId,
    constraints,
    setConstraints,
    goal,
    setGoal,
    level,
    setLevel,
  } = props

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <div>
        <label className="mb-2 block text-sm text-muted-foreground">
          Asset ID
        </label>
        <Input
          value={assetId}
          onChange={(e) => setAssetId(e.target.value)}
          placeholder="asset_demo_001"
        />
        <p className="mt-1 text-xs text-muted-foreground">
          P0: mock asset_id. P1: upload real (camera/arquivo).
        </p>
      </div>

      <div>
        <label className="mb-2 block text-sm text-muted-foreground">
          Constraints (separadas por virgula)
        </label>
        <Input
          value={constraints}
          onChange={(e) => setConstraints(e.target.value)}
          placeholder="dor lombar aguda"
        />
      </div>

      <div>
        <label className="mb-2 block text-sm text-muted-foreground">
          Goal
        </label>
        <Input
          value={goal}
          onChange={(e) => setGoal(e.target.value)}
          placeholder="hypertrophy"
        />
      </div>

      <div>
        <label className="mb-2 block text-sm text-muted-foreground">
          Level
        </label>
        <Select value={level} onValueChange={(v) => setLevel(v as typeof level)}>
          <SelectTrigger className="w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="beginner">Beginner</SelectItem>
            <SelectItem value="intermediate">Intermediate</SelectItem>
            <SelectItem value="advanced">Advanced</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  )
}
