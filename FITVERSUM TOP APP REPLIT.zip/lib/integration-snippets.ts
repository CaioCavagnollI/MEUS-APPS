export const EMBED_IFRAME = `<iframe
  src="https://app.fitversum.com/embed/scanner?token=YOUR_EMBED_TOKEN"
  style="width:100%;height:720px;border:1px solid rgba(255,255,255,.12);border-radius:16px"
  allow="camera; microphone"
  referrerpolicy="no-referrer"
></iframe>`

export const SDK_EXAMPLE = `import { createFitversumScanner } from "@fitversum/scanner-sdk";

const scanner = createFitversumScanner({
  apiBaseUrl: "https://api.fitversum.com",
  token: "USER_OR_EMBED_TOKEN",
  onScanStart: (ctx) => console.log("scan_start", ctx),
  onScanResult: (res) => console.log("scan_result", res.scanId, res.equipId),
  onScanError: (err) => console.error("scan_error", err),
});

await scanner.open({ container: "#scanner-root" });`

export const WEBHOOK_DOC = `POST https://yourapp.com/webhooks/fitversum/scanner
Headers:
  X-FV-Timestamp: <unix_seconds>
  X-FV-Signature: sha256=<hex_hmac>
Body:
  { event, scan_id, user_id, equip_id, confidence, ... }`

export const SECURITY_NOTES = [
  "HTTPS obrigatorio para camera e embeds em producao.",
  "Use allowlist de origins e tokens curtos para embed.",
  "Webhook deve validar assinatura (HMAC) + timestamp (replay protection).",
  "Nunca confie no client para definir equip_id final sem auditoria.",
]
