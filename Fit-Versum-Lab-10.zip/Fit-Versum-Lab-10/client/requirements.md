## Packages
framer-motion | Page transitions and sophisticated interaction animations
recharts | Data visualization for the dashboard and scanner metrics
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility to merge tailwind classes without style conflicts

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  display: ["var(--font-display)"],
}
