import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

// Pages
import LandingPage from "./pages/landing";
import LoginPage from "./pages/login";
import DashboardPage from "./pages/dashboard";
import ScannerPage from "./pages/scanner";
import ChatPage from "./pages/chat";
import AcademicoPage from "./pages/academico";
import LojaPage from "./pages/loja";

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/dashboard" component={DashboardPage} />
      <Route path="/scanner" component={ScannerPage} />
      <Route path="/chat" component={ChatPage} />
      <Route path="/academico" component={AcademicoPage} />
      <Route path="/loja" component={LojaPage} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
