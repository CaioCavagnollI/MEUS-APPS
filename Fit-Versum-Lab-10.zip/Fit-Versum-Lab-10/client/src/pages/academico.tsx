import { AppLayout } from "@/components/layout/app-layout";
import { Search, BookMarked, Filter, ExternalLink, Download } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

const MOCK_PAPERS = [
  {
    title: "Effects of Resistance Training Frequency on Measures of Muscle Hypertrophy",
    authors: "Schoenfeld BJ, Ogborn D, Krieger JW.",
    journal: "Sports Med.",
    year: "2016",
    doi: "10.1519/JSC.0000000000000970",
    tags: ["Meta-Analysis", "Hypertrophy", "Frequency"]
  },
  {
    title: "Maximizing Muscle Hypertrophy: A Systematic Review",
    authors: "Schoenfeld BJ, Grgic J, Ogborn D, Krieger JW.",
    journal: "Int J Environ Res Public Health.",
    year: "2017",
    doi: "10.3390/ijerph14121434",
    tags: ["Review", "Volume", "Intensity"]
  },
  {
    title: "The Mechanisms of Muscle Hypertrophy and Their Application to Resistance Training",
    authors: "Schoenfeld BJ.",
    journal: "J Strength Cond Res.",
    year: "2010",
    doi: "10.1519/JSC.0b013e3181e840f3",
    tags: ["Mechanisms", "Tension", "Stress"]
  }
];

export default function AcademicoPage() {
  return (
    <AppLayout>
      <div className="space-y-8 max-w-5xl mx-auto">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-display font-bold tracking-tight">Módulo Acadêmico</h1>
          <p className="text-muted-foreground">Busque e integre papers diretamente de bases como PubMed e Crossref.</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
            <Input 
              placeholder="Buscar termos, DOIs ou autores..." 
              className="pl-10 h-12 bg-card/50 border-white/10 text-base rounded-xl focus-visible:ring-primary/50"
            />
          </div>
          <Button variant="outline" className="h-12 border-white/10 bg-card/50 px-6 rounded-xl">
            <Filter className="mr-2 h-4 w-4" /> Filtros
          </Button>
          <Button className="h-12 px-8 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold rounded-xl">
            Pesquisar
          </Button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between text-sm text-muted-foreground pb-2 border-b border-white/5">
            <span>Resultados de pesquisa (3 encontrados)</span>
            <span>Ordenado por: Relevância</span>
          </div>

          {MOCK_PAPERS.map((paper, i) => (
            <Card key={i} className="glass-panel hover:border-primary/30 transition-colors group">
              <CardContent className="p-6">
                <div className="flex justify-between items-start gap-4">
                  <div className="space-y-3">
                    <h3 className="text-lg font-bold leading-tight group-hover:text-primary transition-colors">
                      {paper.title}
                    </h3>
                    <div className="text-sm text-muted-foreground">
                      <span className="text-foreground/80">{paper.authors}</span> <br/>
                      <span className="italic">{paper.journal}</span> ({paper.year})
                    </div>
                    
                    <div className="flex flex-wrap gap-2 pt-2">
                      {paper.tags.map(tag => (
                        <Badge key={tag} variant="secondary" className="bg-white/5 hover:bg-white/10 text-[10px] tracking-wider">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-col gap-2 shrink-0">
                    <Button variant="outline" size="sm" className="bg-white/5 border-white/10 h-8">
                      <BookMarked className="h-3 w-3 mr-2" /> Salvar
                    </Button>
                    <Button variant="outline" size="sm" className="bg-white/5 border-white/10 h-8">
                      <ExternalLink className="h-3 w-3 mr-2" /> DOI
                    </Button>
                    <Button size="sm" className="bg-primary/10 text-primary hover:bg-primary hover:text-black border-none h-8">
                      <Download className="h-3 w-3 mr-2" /> Citar
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
