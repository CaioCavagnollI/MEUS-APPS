import { useState } from "react";
import { AppLayout } from "@/components/layout/app-layout";
import { motion } from "framer-motion";
import { 
  Send, 
  Bot, 
  User, 
  ShieldCheck, 
  Database,
  Sparkles
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

type Message = { role: "user" | "ai"; content: string; citations?: string[] };

export default function ChatPage() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    { 
      role: "ai", 
      content: "Olá Cientista. Sou o modelo RAG governado do Fitversum. Todas as minhas respostas são baseadas em nossa base de dados revisada por pares. Como posso ajudar com seu protocolo hoje?" 
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMsg = input;
    setMessages(prev => [...prev, { role: "user", content: userMsg }]);
    setInput("");
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      setMessages(prev => [...prev, { 
        role: "ai", 
        content: `Baseado nas diretrizes atuais de hipertrofia, para "${userMsg}", o recomendado é manter o volume entre 10-20 séries semanais por grupo muscular, com proximidade à falha (RIR 1-3).`,
        citations: ["Schoenfeld, B. J. (2010)", "Helms, E. R., et al. (2016)"]
      }]);
      setIsTyping(false);
    }, 1500);
  };

  return (
    <AppLayout>
      <div className="h-[calc(100vh-8rem)] flex flex-col max-w-4xl mx-auto">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-display font-bold tracking-tight mb-1">Fitversum IA</h1>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Database className="h-3 w-3" /> Conectado ao Core Index (45k papers)
            </div>
          </div>
          <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20 backdrop-blur-md">
            <ShieldCheck className="w-3 h-3 mr-1" /> RAG Strict Mode
          </Badge>
        </div>

        <Card className="flex-1 glass-panel flex flex-col overflow-hidden">
          {/* Chat History */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {messages.map((msg, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-4 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
              >
                <div className={`h-10 w-10 shrink-0 rounded-full flex items-center justify-center ${
                  msg.role === "user" 
                    ? "bg-secondary text-secondary-foreground" 
                    : "bg-primary/10 text-primary border border-primary/20 shadow-[0_0_15px_rgba(0,212,255,0.15)]"
                }`}>
                  {msg.role === "user" ? <User className="h-5 w-5" /> : <Bot className="h-5 w-5" />}
                </div>
                
                <div className={`flex flex-col gap-2 max-w-[80%] ${msg.role === "user" ? "items-end" : "items-start"}`}>
                  <div className={`p-4 rounded-2xl text-sm leading-relaxed ${
                    msg.role === "user" 
                      ? "bg-primary text-primary-foreground rounded-tr-sm" 
                      : "bg-white/5 border border-white/10 rounded-tl-sm"
                  }`}>
                    {msg.content}
                  </div>
                  
                  {msg.citations && (
                    <div className="flex flex-wrap gap-2 mt-1">
                      {msg.citations.map((cit, idx) => (
                        <span key={idx} className="inline-flex items-center text-[10px] font-mono text-muted-foreground bg-black/30 px-2 py-1 rounded border border-white/5">
                          <BookOpen className="h-3 w-3 mr-1" /> {cit}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            ))}

            {isTyping && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-4">
                <div className="h-10 w-10 shrink-0 rounded-full bg-primary/10 text-primary border border-primary/20 flex items-center justify-center">
                  <Sparkles className="h-4 w-4 animate-pulse" />
                </div>
                <div className="bg-white/5 border border-white/10 p-4 rounded-2xl rounded-tl-sm flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-primary/50 animate-bounce" />
                  <div className="w-2 h-2 rounded-full bg-primary/50 animate-bounce" style={{ animationDelay: "0.2s" }} />
                  <div className="w-2 h-2 rounded-full bg-primary/50 animate-bounce" style={{ animationDelay: "0.4s" }} />
                </div>
              </motion.div>
            )}
          </div>

          {/* Input Area */}
          <div className="p-4 bg-background/50 border-t border-white/5 backdrop-blur-md">
            <form onSubmit={handleSend} className="relative flex items-center">
              <Input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Consulte a base de dados sobre protocolos..." 
                className="pr-14 h-14 bg-black/20 border-white/10 text-base rounded-xl focus-visible:ring-primary/50 shadow-inner"
              />
              <Button 
                type="submit" 
                size="icon"
                disabled={!input.trim() || isTyping}
                className="absolute right-2 h-10 w-10 bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg shadow-lg"
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
            <div className="text-center mt-2 text-[10px] text-muted-foreground">
              A IA pode cometer erros. Sempre verifique as citações fornecidas.
            </div>
          </div>
        </Card>
      </div>
    </AppLayout>
  );
}
