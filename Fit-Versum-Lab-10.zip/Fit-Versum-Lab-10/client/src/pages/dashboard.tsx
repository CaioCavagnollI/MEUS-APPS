import { AppLayout } from "@/components/layout/app-layout";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  ScanLine,
  MessageSquare,
  Dumbbell,
  BookOpen,
  TrendingUp,
  ShieldCheck,
  Activity,
  ArrowUpRight
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const QUICK_ACTIONS = [
  { href: "/chat", icon: MessageSquare, title: "Fitversum IA", desc: "Chat com citações científicas", badge: "RAG Fechado" },
  { href: "/scanner", icon: ScanLine, title: "FitScanner", desc: "Reconhecimento biométrico", badge: "P0" },
  { href: "/academico", icon: BookOpen, title: "Acadêmico", desc: "Busca PubMed, Crossref", badge: "Web Permitido" },
  { href: "/loja", icon: Dumbbell, title: "Loja", desc: "Downloads e e-books", badge: "Publishing" },
];

const RECENT_ACTIVITY = [
  { type: "scan", text: "Scanner: Smith Machine identificada", time: "2min atrás" },
  { type: "chat", text: "IA: Consulta sobre hipertrofia", time: "15min atrás" },
  { type: "workout", text: "Treino gerado: Push/Pull/Legs", time: "1h atrás" },
  { type: "academic", text: "Busca: periodização ondulatória", time: "3h atrás" },
];

export default function DashboardPage() {
  return (
    <AppLayout>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold tracking-tight text-white mb-2">Painel de Controle</h1>
            <p className="text-muted-foreground">Visão geral do sistema e telemetria de laboratório.</p>
          </div>
          <Button variant="outline" className="border-primary/20 bg-primary/5 hover:bg-primary/10 text-primary">
            <Activity className="mr-2 h-4 w-4" />
            Gerar Relatório
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: "Scans Processados", value: "1,204", icon: ScanLine, trend: "+12%" },
            { label: "Consultas IA", value: "8,432", icon: MessageSquare, trend: "+24%" },
            { label: "Protocolos Gerados", value: "342", icon: Dumbbell, trend: "+8%" },
            { label: "Citações Validadas", value: "15.2k", icon: ShieldCheck, trend: "+42%" },
          ].map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="glass-panel overflow-hidden relative group">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                  <stat.icon className="h-16 w-16 text-primary" />
                </div>
                <CardContent className="p-6 relative z-10">
                  <p className="text-sm font-medium text-muted-foreground mb-1">{stat.label}</p>
                  <div className="flex items-end gap-3">
                    <h3 className="text-3xl font-display font-bold text-foreground">{stat.value}</h3>
                    <span className="text-xs font-semibold text-emerald-400 flex items-center mb-1">
                      {stat.trend} <ArrowUpRight className="h-3 w-3 ml-0.5" />
                    </span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-xl font-display font-semibold mb-4">Módulos Rápidos</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {QUICK_ACTIONS.map((action, i) => (
              <motion.div
                key={action.title}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 + (i * 0.1) }}
              >
                <Link href={action.href}>
                  <Card className="h-full bg-card/40 border-white/5 hover:bg-card/60 hover:border-primary/30 transition-all duration-300 cursor-pointer group">
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between mb-4">
                        <div className="p-2.5 rounded-xl bg-white/5 group-hover:bg-primary/20 text-muted-foreground group-hover:text-primary transition-colors">
                          <action.icon className="h-5 w-5" />
                        </div>
                        <Badge variant="outline" className="bg-background/50 border-white/10 text-[10px] uppercase tracking-wider text-muted-foreground">
                          {action.badge}
                        </Badge>
                      </div>
                      <h3 className="font-semibold text-foreground mb-1 group-hover:text-primary transition-colors">{action.title}</h3>
                      <p className="text-sm text-muted-foreground">{action.desc}</p>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Telemetry & Activity */}
        <div className="grid lg:grid-cols-2 gap-6">
          <Card className="glass-panel">
            <CardHeader className="border-b border-white/5 pb-4">
              <CardTitle className="text-lg font-display flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" /> Log de Operações
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-white/5">
                {RECENT_ACTIVITY.map((item, i) => (
                  <div key={i} className="flex items-center justify-between p-4 hover:bg-white/5 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-primary/50" />
                      <span className="text-sm font-medium">{item.text}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">{item.time}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="glass-panel">
            <CardHeader className="border-b border-white/5 pb-4">
              <CardTitle className="text-lg font-display flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-primary" /> Status de Governança
              </CardTitle>
            </CardHeader>
            <CardContent className="p-5 space-y-4">
              {[
                { label: "RAG Core Integridade", status: "Estável", color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" },
                { label: "Trilha de Auditoria", status: "Ativa", color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" },
                { label: "Isolamento de Tenant", status: "Validado", color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" },
                { label: "Taxa de API", status: "45% Uso", color: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between bg-black/20 rounded-lg p-3 border border-white/5">
                  <span className="text-sm font-medium text-muted-foreground">{item.label}</span>
                  <Badge variant="outline" className={item.color}>{item.status}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
