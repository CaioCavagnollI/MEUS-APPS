import { Link } from "wouter";
import { motion } from "framer-motion";
import { 
  Brain, 
  ScanLine, 
  ShieldCheck, 
  BookOpen, 
  ShoppingBag, 
  Dna,
  ArrowRight,
  Activity,
  FlaskConical
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const FEATURES = [
  {
    icon: Brain,
    title: "IA Governada (RAG Fechado)",
    description: "Respostas exclusivamente de fontes aprovadas e curadas. Sem hallucination.",
  },
  {
    icon: ScanLine,
    title: "FitScanner",
    description: "Reconhecimento de equipamento com exercícios, músculos e evidências.",
  },
  {
    icon: ShieldCheck,
    title: "Prescrição Auditável",
    description: "Cada treino gerado tem citações, scan_id e trilha de auditoria completa.",
  },
  {
    icon: BookOpen,
    title: "Módulo Acadêmico",
    description: "Busca em PubMed, Crossref e OpenAlex. Formatação ABNT/APA.",
  },
  {
    icon: ShoppingBag,
    title: "Loja & Publishing",
    description: "Downloads protegidos, entitlements, royalties e sistema de afiliados.",
  },
  {
    icon: Dna,
    title: "Editorial & Orientação",
    description: "Revisão acadêmica 100% in-app com patches e entrega DOCX/PDF.",
  },
];

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden selection:bg-primary/30">
      {/* Background Effects */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-primary/10 blur-[150px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-accent/10 blur-[150px]" />
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.03] mix-blend-overlay" />
      </div>

      {/* Nav */}
      <header className="fixed top-0 w-full z-50 border-b border-white/5 bg-background/50 backdrop-blur-xl">
        <div className="mx-auto max-w-7xl flex items-center justify-between px-6 py-4">
          <Link href="/" className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent shadow-lg shadow-primary/20">
              <FlaskConical className="h-5 w-5 text-primary-foreground" />
            </div>
            <div className="flex flex-col">
              <span className="font-display font-bold text-lg leading-none tracking-tight">Fitversum</span>
              <span className="text-[10px] font-medium text-primary tracking-widest uppercase">Laboratory</span>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            <Button variant="ghost" className="text-muted-foreground hover:text-foreground hidden sm:flex" asChild>
              <Link href="/login">Entrar no Sistema</Link>
            </Button>
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20" asChild>
              <Link href="/dashboard">Inicializar Ambiente</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="relative pt-32 pb-20">
        {/* Hero */}
        <section className="px-6 py-20 lg:py-32">
          <div className="mx-auto max-w-4xl text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="mb-8 flex items-center justify-center gap-3">
                <Badge variant="outline" className="border-primary/30 bg-primary/5 text-primary px-3 py-1 rounded-full text-xs font-semibold backdrop-blur-sm">
                  <Activity className="w-3 h-3 mr-2 animate-pulse" />
                  Sistema Operacional Ativo
                </Badge>
              </div>

              <h1 className="text-5xl lg:text-7xl font-display font-extrabold tracking-tight mb-8">
                O Multiverso Científico da <br />
                <span className="text-gradient">Performance Humana</span>
              </h1>

              <p className="mx-auto max-w-2xl text-lg text-muted-foreground leading-relaxed mb-12">
                Ecossistema SaaS com inteligência artificial governada, prescrição auditável, scanner biométrico e módulos acadêmicos de ponta.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button size="lg" className="w-full sm:w-auto h-14 px-8 text-base bg-gradient-to-r from-primary to-blue-500 hover:from-primary/90 hover:to-blue-500/90 shadow-xl shadow-primary/25 rounded-xl border border-white/10" asChild>
                  <Link href="/dashboard">
                    Acessar Laboratório
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button variant="outline" size="lg" className="w-full sm:w-auto h-14 px-8 text-base border-white/10 bg-white/5 hover:bg-white/10 rounded-xl backdrop-blur-md" asChild>
                  <Link href="/scanner">Documentação FitScanner</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Features */}
        <section className="px-6 py-24 bg-card/30 border-y border-white/5 backdrop-blur-sm">
          <div className="mx-auto max-w-7xl">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-display font-bold mb-4">Tudo para ciência aplicada</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Do scanner à prescrição, cada módulo foi projetado para autoridade, precisão e rastreabilidade total.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {FEATURES.map((feature, i) => {
                const Icon = feature.icon;
                return (
                  <motion.div
                    key={feature.title}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: i * 0.1 }}
                    className="glass-panel rounded-2xl p-8 hover-glow group"
                  >
                    <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
