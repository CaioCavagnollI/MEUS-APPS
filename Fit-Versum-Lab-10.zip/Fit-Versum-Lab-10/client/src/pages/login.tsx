import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { FlaskConical, Lock, Mail, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function LoginPage() {
  const [, setLocation] = useLocation();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock login, redirect to dashboard
    setLocation("/dashboard");
  };

  return (
    <div className="min-h-screen flex bg-background relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
        <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] rounded-full bg-primary/10 blur-[120px]" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] rounded-full bg-accent/10 blur-[120px]" />
      </div>

      <div className="w-full flex items-center justify-center p-6 relative z-10">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-md"
        >
          <div className="glass-panel rounded-3xl p-8 sm:p-12 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary via-accent to-primary" />
            
            <div className="flex flex-col items-center text-center mb-10">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent shadow-lg shadow-primary/20 mb-6">
                <FlaskConical className="h-8 w-8 text-primary-foreground" />
              </div>
              <h1 className="text-3xl font-display font-bold tracking-tight mb-2">Acesso Restrito</h1>
              <p className="text-muted-foreground text-sm">
                Autentique-se para acessar o laboratório Fitversum.
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-muted-foreground">Credencial (Email)</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-5 w-5 text-muted-foreground/50" />
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="cientista@fitversum.com" 
                    className="pl-10 h-12 bg-white/5 border-white/10 focus-visible:ring-primary/50"
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" className="text-muted-foreground">Chave de Acesso</Label>
                  <a href="#" className="text-xs text-primary hover:underline">Recuperar chave?</a>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-5 w-5 text-muted-foreground/50" />
                  <Input 
                    id="password" 
                    type="password" 
                    placeholder="••••••••" 
                    className="pl-10 h-12 bg-white/5 border-white/10 focus-visible:ring-primary/50"
                    required
                  />
                </div>
              </div>

              <Button type="submit" className="w-full h-12 text-base font-semibold bg-primary hover:bg-primary/90 shadow-lg shadow-primary/25 mt-4">
                Iniciar Sessão <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </form>

            <div className="mt-8 text-center text-sm text-muted-foreground">
              Não possui credenciais? <Link href="/" className="text-primary hover:underline">Solicite acesso</Link>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
