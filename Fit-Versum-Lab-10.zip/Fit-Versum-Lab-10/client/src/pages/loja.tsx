import { AppLayout } from "@/components/layout/app-layout";
import { DownloadCloud, Star, Lock } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const PRODUCTS = [
  {
    title: "Manual Prático de Periodização",
    type: "E-Book (PDF)",
    price: "R$ 49,90",
    rating: "4.9",
    image: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=600&auto=format&fit=crop", // yoga/fitness abstract
    locked: false,
  },
  {
    title: "Planilhas Avançadas de Carga",
    type: "Template (XLSX)",
    price: "R$ 89,90",
    rating: "5.0",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=600&auto=format&fit=crop", // data/charts abstract
    locked: true,
  },
  {
    title: "Masterclass: Biomecânica RAG",
    type: "Vídeo Aula",
    price: "Premium",
    rating: "4.8",
    image: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=600&auto=format&fit=crop", // gym environment
    locked: true,
  }
];

export default function LojaPage() {
  return (
    <AppLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-display font-bold tracking-tight mb-2">Loja & Publishing</h1>
          <p className="text-muted-foreground">Recursos exclusivos, templates e materiais educacionais protegidos.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {PRODUCTS.map((item, i) => (
            <Card key={i} className="glass-panel overflow-hidden flex flex-col group border-white/5">
              <div className="h-48 overflow-hidden relative">
                {/* Unsplash abstract images for digital products */}
                <img 
                  src={item.image} 
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 opacity-70 mix-blend-luminosity"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />
                <Badge className="absolute top-4 left-4 bg-background/80 backdrop-blur-md border-white/10 text-xs">
                  {item.type}
                </Badge>
              </div>
              
              <CardHeader className="pt-4 pb-2">
                <h3 className="text-xl font-bold font-display leading-tight">{item.title}</h3>
                <div className="flex items-center gap-1 text-sm text-yellow-500 mt-2">
                  <Star className="h-4 w-4 fill-current" />
                  <span className="font-medium">{item.rating}</span>
                </div>
              </CardHeader>
              
              <CardContent className="flex-1">
                {/* Description placeholder */}
              </CardContent>

              <CardFooter className="pt-4 border-t border-white/5 flex items-center justify-between bg-white/[0.02]">
                <span className="font-bold text-lg">{item.price}</span>
                {item.locked ? (
                  <Button variant="secondary" className="bg-white/10 hover:bg-white/20">
                    <Lock className="h-4 w-4 mr-2" /> Desbloquear
                  </Button>
                ) : (
                  <Button className="bg-primary hover:bg-primary/90 text-black font-semibold">
                    <DownloadCloud className="h-4 w-4 mr-2" /> Baixar
                  </Button>
                )}
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
