import { useState } from "react";
import { AppLayout } from "@/components/layout/app-layout";
import { motion, AnimatePresence } from "framer-motion";
import { useCreateScan } from "@/hooks/use-scans";
import { 
  Upload, 
  ScanLine, 
  Cpu, 
  Dna, 
  CheckCircle2, 
  AlertCircle,
  FileImage,
  RefreshCw
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export default function ScannerPage() {
  const [file, setFile] = useState<File | null>(null);
  const [goal, setGoal] = useState("hypertrophy");
  const [level, setLevel] = useState("intermediate");
  const [constraints, setConstraints] = useState("");
  
  const createScan = useCreateScan();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleAnalyze = () => {
    if (!file) return;
    
    // Simulate real upload & processing delay
    createScan.mutate({
      equipmentName: "Smith Machine (Mock)",
      equipmentId: "smith_machine",
      confidence: 94,
      details: {
        goal,
        level,
        constraints,
        muscles: ["Quadriceps", "Gluteus Maximus", "Pectoralis Major"],
        exercises: ["Smith Machine Squat", "Smith Bench Press"]
      }
    });
  };

  return (
    <AppLayout>
      <div className="space-y-6 max-w-4xl mx-auto">
        <div>
          <h1 className="text-3xl font-display font-bold tracking-tight mb-2">FitScanner</h1>
          <p className="text-muted-foreground">Análise biométrica e reconhecimento de equipamento via Visão Computacional.</p>
        </div>

        <div className="grid md:grid-cols-5 gap-6">
          {/* Upload & Config Area */}
          <div className="md:col-span-2 space-y-6">
            <Card className="glass-panel">
              <CardHeader>
                <CardTitle className="text-lg">Parâmetros de Análise</CardTitle>
                <CardDescription>Configure os vetores de saída</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Objetivo Principal</Label>
                  <Select value={goal} onValueChange={setGoal}>
                    <SelectTrigger className="bg-black/20 border-white/10">
                      <SelectValue placeholder="Selecione o objetivo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hypertrophy">Hipertrofia</SelectItem>
                      <SelectItem value="strength">Força Máxima</SelectItem>
                      <SelectItem value="endurance">Resistência</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Nível Operacional</Label>
                  <Select value={level} onValueChange={setLevel}>
                    <SelectTrigger className="bg-black/20 border-white/10">
                      <SelectValue placeholder="Selecione o nível" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Iniciante</SelectItem>
                      <SelectItem value="intermediate">Intermediário</SelectItem>
                      <SelectItem value="advanced">Avançado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Restrições (Opcional)</Label>
                  <Input 
                    placeholder="Ex: Dor lombar aguda" 
                    value={constraints}
                    onChange={(e) => setConstraints(e.target.value)}
                    className="bg-black/20 border-white/10"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="border-dashed border-2 border-white/20 bg-transparent hover:border-primary/50 transition-colors">
              <CardContent className="p-8 flex flex-col items-center justify-center text-center">
                <input 
                  type="file" 
                  id="image-upload" 
                  className="hidden" 
                  accept="image/*"
                  onChange={handleFileChange}
                />
                <Label htmlFor="image-upload" className="cursor-pointer flex flex-col items-center">
                  <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-4 text-primary">
                    {file ? <FileImage className="h-8 w-8" /> : <Upload className="h-8 w-8" />}
                  </div>
                  <span className="font-semibold text-lg mb-1">
                    {file ? file.name : "Carregar Imagem"}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {file ? "Clique para trocar" : "JPEG, PNG, WEBP (Max 5MB)"}
                  </span>
                </Label>
              </CardContent>
              {file && (
                <CardFooter className="bg-black/20 border-t border-white/5 py-3">
                  <Button 
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold shadow-lg shadow-primary/20"
                    onClick={handleAnalyze}
                    disabled={createScan.isPending}
                  >
                    {createScan.isPending ? (
                      <><RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Processando Imagem...</>
                    ) : (
                      <><ScanLine className="mr-2 h-4 w-4" /> Executar FitScanner</>
                    )}
                  </Button>
                </CardFooter>
              )}
            </Card>
          </div>

          {/* Results Area */}
          <div className="md:col-span-3">
            <AnimatePresence mode="wait">
              {!createScan.data && !createScan.isPending ? (
                <motion.div 
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }} 
                  exit={{ opacity: 0 }}
                  className="h-full min-h-[400px] rounded-2xl border border-white/5 bg-black/10 flex flex-col items-center justify-center text-muted-foreground"
                >
                  <Cpu className="h-16 w-16 mb-4 opacity-20" />
                  <p>Aguardando submissão de arquivo para análise RAG.</p>
                </motion.div>
              ) : createScan.isPending ? (
                <motion.div 
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  className="h-full min-h-[400px] rounded-2xl glass-panel flex flex-col items-center justify-center relative overflow-hidden"
                >
                  <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.03] mix-blend-overlay" />
                  <ScanLine className="h-16 w-16 text-primary animate-pulse mb-6" />
                  <h3 className="text-xl font-display font-bold mb-2">Processando Vetores</h3>
                  <div className="w-48 h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full animate-[progress_2s_ease-in-out_infinite]" style={{ width: '60%' }} />
                  </div>
                </motion.div>
              ) : (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }} 
                  animate={{ opacity: 1, scale: 1 }}
                  className="space-y-4"
                >
                  <Card className="glass-panel border-emerald-500/20">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                          <CheckCircle2 className="h-3 w-3 mr-1" /> Análise Concluída
                        </Badge>
                        <span className="text-xs font-mono text-muted-foreground">ID: {createScan.data?.id.toString().padStart(6, '0')}</span>
                      </div>
                      <CardTitle className="text-2xl font-display mt-4">
                        {createScan.data?.equipmentName}
                      </CardTitle>
                      <CardDescription>
                        Confiança do modelo: <span className="text-primary font-bold">{createScan.data?.confidence}%</span>
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid sm:grid-cols-2 gap-4 mt-4">
                        <div className="bg-black/20 rounded-xl p-4 border border-white/5">
                          <div className="flex items-center gap-2 mb-3 text-sm font-medium text-muted-foreground">
                            <Dna className="h-4 w-4" /> Grupos Musculares
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {(createScan.data?.details as any)?.muscles.map((m: string) => (
                              <Badge key={m} variant="secondary" className="bg-white/5">{m}</Badge>
                            ))}
                          </div>
                        </div>
                        <div className="bg-black/20 rounded-xl p-4 border border-white/5">
                          <div className="flex items-center gap-2 mb-3 text-sm font-medium text-muted-foreground">
                            <Activity className="h-4 w-4" /> Exercícios Base
                          </div>
                          <ul className="space-y-2 text-sm">
                            {(createScan.data?.details as any)?.exercises.map((e: string) => (
                              <li key={e} className="flex items-center gap-2 before:content-[''] before:w-1.5 before:h-1.5 before:bg-primary before:rounded-full">
                                {e}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div className="mt-6 bg-blue-500/5 border border-blue-500/20 rounded-xl p-4 flex items-start gap-3">
                        <ShieldCheck className="h-5 w-5 text-blue-400 shrink-0 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-bold text-blue-400 mb-1">Citação Científica Validada</h4>
                          <p className="text-xs text-muted-foreground italic">
                            "A máquina guiada oferece estabilidade para hipertrofia com menor exigência do core comparado ao peso livre." 
                            — Schwanbeck et al., J Strength Cond Res.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
