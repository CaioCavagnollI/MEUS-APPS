import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

async function seedDatabase() {
  const existingScans = await storage.getScans();
  if (existingScans.length === 0) {
    await storage.createScan({
      equipmentName: "Smith Machine",
      equipmentId: "smith_machine",
      confidence: 84,
      details: {
        muscles: ["Quadriceps", "Pectoralis Major", "Deltoid Anterior"],
        exercises: ["Smith Machine Squat", "Smith Machine Bench Press"]
      }
    });
    await storage.createScan({
      equipmentName: "Cable Crossover",
      equipmentId: "cable_crossover",
      confidence: 92,
      details: {
        muscles: ["Pectoralis Major", "Deltoid Anterior", "Triceps Brachii"],
        exercises: ["Cable Flyes", "Cable Crunches"]
      }
    });
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Seed initial data
  seedDatabase().catch(console.error);

  app.get(api.scans.list.path, async (req, res) => {
    const scansList = await storage.getScans();
    res.json(scansList);
  });

  app.get(api.scans.get.path, async (req, res) => {
    const scan = await storage.getScan(Number(req.params.id));
    if (!scan) {
      return res.status(404).json({ message: 'Scan not found' });
    }
    res.json(scan);
  });

  app.post(api.scans.create.path, async (req, res) => {
    try {
      const input = api.scans.create.input.parse(req.body);
      const scan = await storage.createScan(input);
      res.status(201).json(scan);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  return httpServer;
}
