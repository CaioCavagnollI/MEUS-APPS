import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-primary-foreground font-bold text-lg">
              FL
            </span>
          </div>
          <CardTitle className="text-xl">Entrar no Fitversum Lab</CardTitle>
          <CardDescription>
            Acesse o multiverso cientifico da musculacao
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="mb-2 block text-sm text-muted-foreground">
              Email
            </label>
            <Input type="email" placeholder="seu@email.com" />
          </div>
          <div>
            <label className="mb-2 block text-sm text-muted-foreground">
              Senha
            </label>
            <Input type="password" placeholder="Sua senha" />
          </div>
          <Button className="w-full" asChild>
            <Link href="/dashboard">Entrar</Link>
          </Button>
          <div className="text-center">
            <span className="text-xs text-muted-foreground">
              Nao tem conta?{" "}
              <Link href="/dashboard" className="text-primary hover:underline">
                Criar conta
              </Link>
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
