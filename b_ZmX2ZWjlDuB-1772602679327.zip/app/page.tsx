import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  ScanLine,
  Brain,
  ShieldCheck,
  BookOpen,
  ShoppingBag,
  ArrowRight,
  Dna,
  Target,
  Zap,
} from "lucide-react"

const FEATURES = [
  {
    icon: Brain,
    title: "IA Governada (RAG Fechado)",
    description:
      "Respostas exclusivamente de fontes aprovadas e curadas. Sem hallucination.",
  },
  {
    icon: ScanLine,
    title: "FitScanner",
    description:
      "Reconhecimento de equipamento com exercicios, musculos e evidencias.",
  },
  {
    icon: ShieldCheck,
    title: "Prescricao Auditavel",
    description:
      "Cada treino gerado tem citacoes, scan_id e trilha de auditoria completa.",
  },
  {
    icon: BookOpen,
    title: "Modulo Academico",
    description:
      "Busca em PubMed, Crossref e OpenAlex. Formatacao ABNT/APA/Vancouver.",
  },
  {
    icon: ShoppingBag,
    title: "Loja & Publishing",
    description:
      "Downloads protegidos, entitlements, royalties e sistema de afiliados.",
  },
  {
    icon: Dna,
    title: "Editorial & Orientacao",
    description:
      "Revisao academica 100% in-app com patches e entrega DOCX/PDF.",
  },
]

const STATS = [
  { value: "RAG", label: "Fechado & Governado" },
  { value: "100%", label: "Rastreavel" },
  { value: "P0", label: "Scanner Defensavel" },
  { value: "5+", label: "Roles & Planos" },
]

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Nav */}
      <header className="sticky top-0 z-30 border-b border-border bg-background/70 backdrop-blur-lg">
        <div className="flex items-center justify-between px-4 py-3">
          <Link href="/" className="flex items-center gap-2">
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground font-bold text-sm">
              FL
            </span>
            <div className="leading-tight">
              <div className="text-sm font-semibold text-foreground">
                Fitversum Lab
              </div>
              <div className="text-[10px] text-muted-foreground">
                {"Ciencia & Performance"}
              </div>
            </div>
          </Link>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/login">Entrar</Link>
            </Button>
            <Button size="sm" asChild>
              <Link href="/dashboard">Comecar</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--primary)_0%,_transparent_50%)] opacity-[0.07]" />
        <div className="relative px-4 py-16 lg:py-32">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-4 flex items-center justify-center gap-2">
              <Badge className="bg-primary/10 text-primary border-primary/20">
                Novo
              </Badge>
              <span className="text-xs text-muted-foreground">
                FitScanner com desambiguacao
              </span>
            </div>

            <h1 className="text-balance text-3xl font-bold tracking-tight lg:text-5xl">
              O Multiverso Cientifico da{" "}
              <span className="text-primary">Musculacao</span>
            </h1>

            <p className="mx-auto mt-4 max-w-xl text-pretty text-base text-muted-foreground leading-relaxed lg:text-lg">
              Ecossistema SaaS com IA governada, prescricao auditavel, scanner
              inteligente e modulo academico.
            </p>

            <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
              <Button size="lg" className="w-full sm:w-auto" asChild>
                <Link href="/dashboard">
                  Acessar Dashboard
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="w-full sm:w-auto"
                asChild
              >
                <Link href="/scanner">Explorar FitScanner</Link>
              </Button>
            </div>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
              <Badge
                variant="outline"
                className="border-border text-muted-foreground"
              >
                <ShieldCheck className="mr-1 size-3" />
                RAG Fechado
              </Badge>
              <Badge
                variant="outline"
                className="border-border text-muted-foreground"
              >
                <Target className="mr-1 size-3" />
                Auditavel
              </Badge>
              <Badge
                variant="outline"
                className="border-border text-muted-foreground"
              >
                <Zap className="mr-1 size-3" />
                Deterministico
              </Badge>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-y border-border bg-card">
        <div className="px-4 py-10 lg:py-16">
          <div className="mx-auto max-w-4xl grid grid-cols-2 gap-6 lg:grid-cols-4">
            {STATS.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-2xl font-bold text-primary lg:text-3xl">
                  {stat.value}
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="px-4 py-16 lg:py-24">
        <div className="mx-auto max-w-5xl">
          <div className="text-center mb-10">
            <h2 className="text-balance text-2xl font-bold lg:text-3xl">
              Tudo para{" "}
              <span className="text-primary">ciencia aplicada</span>
            </h2>
            <p className="mt-3 text-sm text-muted-foreground leading-relaxed lg:text-base">
              Do scanner a prescricao, cada modulo foi projetado para autoridade e rastreabilidade.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((feature) => {
              const Icon = feature.icon
              return (
                <div
                  key={feature.title}
                  className="group rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary/30 active:border-primary/30"
                >
                  <div className="inline-flex rounded-lg bg-primary/10 p-2.5">
                    <Icon className="size-5 text-primary" />
                  </div>
                  <h3 className="mt-3 text-sm font-semibold text-foreground">
                    {feature.title}
                  </h3>
                  <p className="mt-1.5 text-xs text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border bg-card">
        <div className="px-4 py-16 text-center lg:py-24">
          <h2 className="text-balance text-2xl font-bold lg:text-3xl">
            Pronto para o{" "}
            <span className="text-primary">Multiverso Cientifico</span>?
          </h2>
          <p className="mx-auto mt-3 max-w-lg text-sm text-muted-foreground leading-relaxed lg:text-base">
            Junte-se ao ecossistema onde cada resposta tem evidencia e cada prescricao tem auditoria.
          </p>
          <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
            <Button size="lg" className="w-full sm:w-auto" asChild>
              <Link href="/dashboard">
                Comecar Agora
                <ArrowRight className="size-4" />
              </Link>
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="w-full sm:w-auto"
              asChild
            >
              <Link href="/integration">Ver Integracoes</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border">
        <div className="px-4 py-6">
          <div className="flex flex-col items-center gap-4 text-center sm:flex-row sm:justify-between sm:text-left">
            <div className="flex items-center gap-2">
              <span className="inline-flex h-5 w-5 items-center justify-center rounded bg-primary text-primary-foreground font-bold text-[8px]">
                FL
              </span>
              <span className="text-xs text-muted-foreground">
                {"Fitversum Lab — Ciencia & Performance"}
              </span>
            </div>
            <div className="flex gap-4 text-xs text-muted-foreground">
              <Link href="/loja" className="hover:text-foreground transition-colors">
                Loja
              </Link>
              <Link href="/academico" className="hover:text-foreground transition-colors">
                Academico
              </Link>
              <Link href="/integration" className="hover:text-foreground transition-colors">
                Integracoes
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
