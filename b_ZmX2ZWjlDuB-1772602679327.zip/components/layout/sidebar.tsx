"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Badge } from "@/components/ui/badge"
import {
  LayoutDashboard,
  MessageSquare,
  ScanLine,
  ShoppingBag,
  GraduationCap,
  Plug,
  Shield,
  Rss,
  Upload,
} from "lucide-react"

const NAV_LINKS = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/chat", label: "Fitversum IA", icon: MessageSquare },
  { href: "/scanner", label: "FitScanner", icon: ScanLine },
  { href: "/feed", label: "Feed", icon: Rss },
  { href: "/loja", label: "Loja", icon: ShoppingBag },
  { href: "/academico", label: "Academico", icon: GraduationCap },
  { href: "/uploads", label: "Uploads", icon: Upload },
  { href: "/integration", label: "Integracoes", icon: Plug },
  { href: "/admin", label: "Admin", icon: Shield },
]

export function DesktopSidebar() {
  const pathname = usePathname()

  return (
    <aside className="hidden lg:flex fixed top-0 left-0 z-30 h-screen w-60 flex-col border-r border-border bg-sidebar">
      {/* Logo */}
      <div className="flex items-center gap-2 px-4 py-4 border-b border-border">
        <Link href="/" className="flex items-center gap-2">
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground font-bold text-sm">
            FL
          </span>
          <div className="leading-tight">
            <div className="text-sm font-semibold text-foreground">
              Fitversum Lab
            </div>
            <div className="text-[10px] text-muted-foreground">
              {"Ciencia & Performance"}
            </div>
          </div>
        </Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-0.5">
        {NAV_LINKS.map((item) => {
          const Icon = item.icon
          const isActive =
            pathname === item.href || pathname.startsWith(item.href + "/")
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors ${
                isActive
                  ? "bg-primary/10 text-primary font-medium"
                  : "text-muted-foreground hover:text-foreground hover:bg-sidebar-accent"
              }`}
            >
              <Icon className="size-4 shrink-0" />
              {item.label}
              {item.href === "/admin" && (
                <Badge className="ml-auto bg-destructive/10 text-destructive border-destructive/20 text-[9px] px-1.5 py-0">
                  ADM
                </Badge>
              )}
            </Link>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="px-3 pb-4">
        <div className="rounded-xl border border-border bg-secondary/30 p-3">
          <div className="flex items-center gap-2 mb-2">
            <div className="h-7 w-7 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-[10px] font-bold text-primary">A</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-foreground truncate">Admin User</p>
              <p className="text-[10px] text-muted-foreground">admin@fitversum.com</p>
            </div>
          </div>
          <Badge className="bg-primary/10 text-primary border-primary/20 text-[9px]">
            Premium
          </Badge>
        </div>
      </div>
    </aside>
  )
}
