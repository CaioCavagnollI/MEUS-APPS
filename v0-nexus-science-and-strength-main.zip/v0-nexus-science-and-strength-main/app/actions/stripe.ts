'use server'

import { stripe } from '@/lib/stripe'
import { findProduct, type Product } from '@/lib/products'
import { createClient } from '@/lib/supabase/server'

export async function startCheckoutSession(productId: string, userEmail?: string) {
  const product = await findProduct(productId)
  if (!product) {
    throw new Error(`Product with id "${productId}" not found`)
  }

  const isSubscription = product.type === 'subscription' || product.type === 'trainer'

  // Create Checkout Sessions from body params.
  const session = await stripe.checkout.sessions.create({
    ui_mode: 'embedded',
    redirect_on_completion: 'never',
    customer_email: userEmail,
    line_items: [
      {
        price_data: {
          currency: 'brl',
          product_data: {
            name: product.name,
            description: product.description,
          },
          unit_amount: product.priceInCents,
          ...(isSubscription ? { recurring: { interval: 'month' } } : {}),
        },
        quantity: 1,
      },
    ],
    mode: isSubscription ? 'subscription' : 'payment',
    metadata: {
      productId: product.id,
      productType: product.type,
      bookId: product.bookId || '',
      trainerId: product.trainerId || '',
    },
  })

  return session.client_secret
}

export async function recordPurchase(
  sessionId: string,
  userId: string,
  productId: string,
  productType: string,
  amount: number
) {
  const supabase = await createClient()
  
  await supabase.from('purchases').insert({
    user_id: userId,
    product_id: productId,
    product_type: productType,
    amount_paid: amount / 100,
    stripe_session_id: sessionId,
  })
  
  // Record analytics event
  await supabase.from('analytics_events').insert({
    event_type: 'purchase',
    event_data: { productId, productType, amount },
  })
}
