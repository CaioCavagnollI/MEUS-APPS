import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

// Function to sanitize text by removing invalid Unicode characters
function sanitizeText(text: string): string {
  // Remove invalid surrogate pairs and other problematic characters
  return text
    .replace(/[\uD800-\uDFFF]/g, "") // Remove lone surrogates
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, "") // Remove control characters except tab, newline, carriage return
    .replace(/\uFFFD/g, "") // Remove replacement character
    .trim()
}

// Function to split text into chunks for RAG
function splitIntoChunks(text: string, chunkSize = 1000, overlap = 200): string[] {
  const chunks: string[] = []
  let start = 0

  while (start < text.length) {
    const end = Math.min(start + chunkSize, text.length)
    chunks.push(text.slice(start, end))
    start += chunkSize - overlap
  }

  return chunks
}

// Extract chapter info from text (simple heuristic)
function extractChapter(text: string): string | null {
  const chapterMatch = text.match(/cap[íi]tulo\s+(\d+|[IVXLCDM]+)/i)
  return chapterMatch ? chapterMatch[0] : null
}

export async function POST(req: Request) {
  try {
    const formData = await req.formData()
    const file = formData.get("file") as File | null
    const bookId = formData.get("bookId") as string
    const title = formData.get("title") as string
    const subtitle = formData.get("subtitle") as string | null
    const description = formData.get("description") as string | null
    const price = formData.get("price") as string
    const category = formData.get("category") as string | null

    const supabase = await createClient()

    // If bookId is provided, add content to existing book
    // Otherwise, create new book
    let finalBookId = bookId

    if (!finalBookId && title) {
      // Create new book
      const { data: newBook, error: bookError } = await supabase
        .from("books")
        .insert({
          title,
          subtitle,
          description,
          price: parseFloat(price) || 0,
          category: category || "Treinamento",
        })
        .select("id")
        .single()

      if (bookError) {
        return NextResponse.json({ error: bookError.message }, { status: 500 })
      }

      finalBookId = newBook.id
    }

    // Process file content if provided
    if (file && finalBookId) {
      const rawText = await file.text()
      const text = sanitizeText(rawText)
      const chunks = splitIntoChunks(text)

      // Insert chunks - sanitize each chunk content as well
      const chunkInserts = chunks.map((content, index) => ({
        book_id: finalBookId,
        content: sanitizeText(content),
        chapter: extractChapter(content),
        chunk_index: index,
      }))

      const { error: chunksError } = await supabase
        .from("book_chunks")
        .insert(chunkInserts)

      if (chunksError) {
        return NextResponse.json({ error: chunksError.message }, { status: 500 })
      }

      return NextResponse.json({
        success: true,
        bookId: finalBookId,
        chunksCreated: chunks.length,
      })
    }

    return NextResponse.json({
      success: true,
      bookId: finalBookId,
    })
  } catch (error) {
    console.error("Error uploading book:", error)
    return NextResponse.json(
      { error: "Failed to upload book" },
      { status: 500 }
    )
  }
}
