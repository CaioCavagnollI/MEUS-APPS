import { streamText, convertToModelMessages, tool } from "ai"
import { createClient } from "@/lib/supabase/server"
import { z } from "zod"

export async function POST(req: Request) {
  const { messages, sessionId } = await req.json()

  const supabase = await createClient()

  // Get the user's last message text
  const lastUserMessage = messages.filter((m: { role: string }) => m.role === "user").pop()
  const userQuery = lastUserMessage?.parts?.[0]?.text || lastUserMessage?.content || ""

  // Multi-strategy RAG: combine keyword search + broader matching
  let ragContext = ""

  try {
    // Strategy 1: Full-text search in Portuguese
    const keywords = userQuery
      .split(/\s+/)
      .filter((w: string) => w.length > 3)
      .slice(0, 6)
      .join(" | ")

    const { data: ftsChunks } = await supabase
      .from("book_chunks")
      .select("content, chapter, books(title)")
      .textSearch("content", keywords || userQuery, {
        type: "websearch",
        config: "portuguese",
      })
      .limit(4)

    // Strategy 2: ILIKE fallback for important terms
    const importantTerms = userQuery
      .split(/\s+/)
      .filter((w: string) => w.length > 4)
      .slice(0, 3)

    let ilikeChunks: typeof ftsChunks = []
    if (importantTerms.length > 0) {
      const { data } = await supabase
        .from("book_chunks")
        .select("content, chapter, books(title)")
        .or(importantTerms.map((t: string) => `content.ilike.%${t}%`).join(","))
        .limit(3)
      ilikeChunks = data || []
    }

    // Combine and deduplicate
    const allChunks = [...(ftsChunks || []), ...(ilikeChunks || [])]
    const seen = new Set<string>()
    const uniqueChunks = allChunks.filter((c) => {
      const key = c.content.slice(0, 100)
      if (seen.has(key)) return false
      seen.add(key)
      return true
    }).slice(0, 6)

    if (uniqueChunks.length > 0) {
      ragContext = uniqueChunks
        .map(
          (c: { content: string; chapter: string | null; books: { title: string } | null }) =>
            `[Fonte: ${c.books?.title || "Livro"} - ${c.chapter || "Capítulo"}]\n${c.content}`
        )
        .join("\n\n---\n\n")
    }
  } catch {
    // If search fails, continue without RAG context
  }

  // Fetch list of available books for the AI to reference
  const { data: booksList } = await supabase
    .from("books")
    .select("title, author, category")
    .limit(20)

  const booksRef = booksList?.length
    ? `\nLIVROS DISPONÍVEIS NA PLATAFORMA:\n${booksList.map((b) => `- "${b.title}" (${b.category}) por ${b.author}`).join("\n")}`
    : ""

  const systemPrompt = `Você é o Mentor IA do NEXUS, um assistente especializado em treinamento de força, hipertrofia, periodização e biomecânica. Você foi treinado exclusivamente com os livros de Caio Cavagnolli.

PERSONALIDADE:
- Profissional mas acessível, como um professor universitário explicando para um aluno dedicado
- Use linguagem técnica quando necessário, mas sempre explique os termos
- Seja entusiasmado sobre ciência do treinamento

DIRETRIZES:
- Responda APENAS sobre temas relacionados a treinamento de força, musculação, periodização, biomecânica, nutrição esportiva e recuperação
- Baseie suas respostas no conhecimento científico dos livros quando disponível
- Seja didático e use exemplos práticos sempre que possível
- Se a pergunta não for sobre treinamento/fitness, educadamente redirecione o usuário
- Use português brasileiro
- Cite fontes quando possível (ex: "Como explicado no livro Periodização Científica...")
- Quando recomendar aprofundamento, sugira os livros disponíveis na plataforma
- Estruture respostas longas com bullet points ou numeração para melhor leitura
- Inclua aplicação prática sempre que fizer sentido

${ragContext ? `\nCONTEXTO DOS LIVROS (use como referência principal):\n${ragContext}` : ""}
${booksRef}

Responda de forma clara, objetiva e baseada em evidências científicas.`

  const result = streamText({
    model: "openai/gpt-4o-mini",
    system: systemPrompt,
    messages: await convertToModelMessages(messages),
    tools: {
      searchBooks: tool({
        description: "Busca nos livros de Caio Cavagnolli por um tópico específico",
        inputSchema: z.object({
          query: z.string().describe("O tópico para buscar nos livros"),
        }),
        execute: async ({ query }) => {
          const { data } = await supabase
            .from("book_chunks")
            .select("content, chapter, books(title)")
            .textSearch("content", query, { type: "websearch", config: "portuguese" })
            .limit(3)
          return data?.map((c) => ({
            source: `${(c.books as { title: string } | null)?.title} - ${c.chapter}`,
            excerpt: c.content.slice(0, 500),
          })) || []
        },
      }),
    },
    maxSteps: 3,
  })

  // Save user message to history
  if (sessionId) {
    try {
      await supabase.from("chat_messages").insert({
        session_id: sessionId,
        role: "user",
        content: userQuery,
      })
    } catch {
      // Non-critical, continue
    }
  }

  return result.toUIMessageStreamResponse()
}
