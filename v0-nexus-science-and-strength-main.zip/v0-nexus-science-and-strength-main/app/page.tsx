"use client"

import { useState } from "react"
// NEXUS App - Science & Strength Platform
import { AppShell } from "@/components/nexus/app-shell"
import { HomePage } from "@/components/nexus/home-page"
import { LibraryPage } from "@/components/nexus/library-page"
import { AIMentorPage } from "@/components/nexus/ai-mentor-page"
import { NexusLabPage } from "@/components/nexus/nexus-lab-page"
import { ProfilePage } from "@/components/nexus/profile-page"

type Tab = "home" | "library" | "ai" | "lab" | "profile"

export default function NexusApp() {
  const [activeTab, setActiveTab] = useState<Tab>("home")

  const renderContent = () => {
    switch (activeTab) {
      case "home":
        return <HomePage />
      case "library":
        return <LibraryPage />
      case "ai":
        return <AIMentorPage />
      case "lab":
        return <NexusLabPage />
      case "profile":
        return <ProfilePage />
      default:
        return <HomePage />
    }
  }

  return (
    <AppShell activeTab={activeTab} onTabChange={setActiveTab}>
      {renderContent()}
    </AppShell>
  )
}
