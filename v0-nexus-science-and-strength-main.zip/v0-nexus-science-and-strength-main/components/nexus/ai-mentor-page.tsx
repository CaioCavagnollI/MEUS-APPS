"use client"

import React from "react"
import { useState, useRef, useEffect } from "react"
import { Send, Bot, User, Sparkles, BookOpen, Dumbbell, Apple, Brain, Loader2, RotateCcw, Copy, Check, ThumbsUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { useChat } from "@ai-sdk/react"
import { DefaultChatTransport } from "ai"

const quickActions = [
  { icon: Dumbbell, label: "Periodização", prompt: "Explique os princípios da periodização ondulada e como aplicar no treino" },
  { icon: Apple, label: "Nutrição", prompt: "Qual a importância da proteína para hipertrofia? Quanto devo consumir?" },
  { icon: Brain, label: "Recuperação", prompt: "Como otimizar a recuperação entre treinos de força?" },
  { icon: BookOpen, label: "Biomecânica", prompt: "Qual a biomecânica correta do agachamento e como melhorar a execução?" },
]

const suggestedFollowUps = [
  "Pode dar um exemplo prático de periodização semanal?",
  "Qual a diferença entre força e hipertrofia?",
  "Como evitar lesões no treino de força?",
  "Qual o volume ideal de treino por grupo muscular?",
]

function getMessageText(message: { parts?: Array<{ type: string; text?: string }> }): string {
  if (!message.parts || !Array.isArray(message.parts)) return ""
  return message.parts
    .filter((p): p is { type: "text"; text: string } => p.type === "text" && typeof p.text === "string")
    .map((p) => p.text)
    .join("")
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)
  
  const handleCopy = async () => {
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <button type="button" onClick={handleCopy} className="p-1 rounded hover:bg-secondary transition-colors" title="Copiar">
      {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5 text-muted-foreground" />}
    </button>
  )
}

export function AIMentorPage() {
  const [sessionId] = useState(() => `session_${Date.now()}_${Math.random().toString(36).slice(2)}`)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const [inputValue, setInputValue] = useState("")
  const [likedMessages, setLikedMessages] = useState<Set<string>>(new Set())

  const { messages, sendMessage, status, setMessages } = useChat({
    transport: new DefaultChatTransport({
      api: "/api/chat",
      prepareSendMessagesRequest: ({ id, messages }) => ({
        body: {
          messages,
          sessionId,
          id,
        },
      }),
    }),
  })

  const isLoading = status === "streaming" || status === "submitted"

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = async (text?: string) => {
    const messageText = text || inputValue
    if (!messageText.trim() || isLoading) return
    
    setInputValue("")
    await sendMessage({ text: messageText })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    handleSend()
  }

  const handleNewChat = () => {
    setMessages([])
    inputRef.current?.focus()
  }

  const handleLike = (messageId: string) => {
    setLikedMessages((prev) => {
      const next = new Set(prev)
      if (next.has(messageId)) {
        next.delete(messageId)
      } else {
        next.add(messageId)
      }
      return next
    })
  }

  // Count words for reading time estimate
  const totalAssistantWords = messages
    .filter((m) => m.role === "assistant")
    .reduce((sum, m) => sum + getMessageText(m).split(/\s+/).length, 0)

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <div className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 md:top-16 z-40">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center">
                <Bot className="w-5 h-5 text-cyan-500" />
              </div>
              <div>
                <h1 className="font-bold flex items-center gap-2 text-foreground">
                  Nexus AI Mentor
                  <Badge className="bg-cyan-500/10 text-cyan-500 border-cyan-500/20 text-xs">
                    <Sparkles className="w-3 h-3 mr-1" />
                    RAG
                  </Badge>
                </h1>
                <p className="text-xs text-muted-foreground">
                  {messages.length > 0
                    ? `${messages.length} mensagens`
                    : "Treinada com os livros de Caio Cavagnolli"}
                </p>
              </div>
            </div>
            {messages.length > 0 && (
              <Button variant="ghost" size="sm" onClick={handleNewChat} className="gap-1.5 text-muted-foreground hover:text-foreground">
                <RotateCcw className="w-4 h-4" />
                <span className="hidden sm:inline">Nova conversa</span>
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Quick Actions - shown when no messages */}
      {messages.length === 0 && (
        <div className="container mx-auto px-4 py-8 flex-1 flex flex-col justify-center">
          <div className="text-center mb-8">
            <div className="w-20 h-20 rounded-full bg-cyan-500/10 flex items-center justify-center mx-auto mb-4 ring-2 ring-cyan-500/20">
              <Bot className="w-10 h-10 text-cyan-500" />
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-2">Olá! Sou a Nexus AI</h2>
            <p className="text-muted-foreground text-sm max-w-md mx-auto leading-relaxed">
              Fui treinada com os livros de Caio Cavagnolli sobre treinamento de força, periodização, biomecânica e nutrição esportiva. Pergunte-me qualquer coisa!
            </p>
          </div>
          <p className="text-sm text-muted-foreground mb-4 text-center font-medium">Sugestões para começar:</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-lg mx-auto w-full">
            {quickActions.map((action) => (
              <button
                type="button"
                key={action.label}
                onClick={() => handleSend(action.prompt)}
                disabled={isLoading}
                className="p-4 rounded-xl bg-card border border-border hover:border-cyan-500/50 hover:bg-card/80 transition-all text-left disabled:opacity-50 group"
              >
                <action.icon className="w-5 h-5 text-cyan-500 mb-2 group-hover:scale-110 transition-transform" />
                <p className="font-medium text-sm text-foreground">{action.label}</p>
                <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{action.prompt}</p>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Messages */}
      {messages.length > 0 && (
        <div className="flex-1 container mx-auto px-4 py-4 space-y-4 overflow-y-auto">
          {messages.map((message) => {
            const text = getMessageText(message)
            if (!text) return null
            
            return (
              <div
                key={message.id}
                className={cn(
                  "flex gap-3",
                  message.role === "user" ? "justify-end" : "justify-start"
                )}
              >
                {message.role === "assistant" && (
                  <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center shrink-0 mt-1">
                    <Bot className="w-4 h-4 text-cyan-500" />
                  </div>
                )}
                <div className={cn("max-w-[85%] md:max-w-[70%]")}>
                  <Card className={cn(
                    message.role === "user" 
                      ? "bg-cyan-600 text-white" 
                      : "bg-card"
                  )}>
                    <CardContent className="p-3 md:p-4">
                      <p className={cn(
                        "text-sm whitespace-pre-line leading-relaxed",
                        message.role === "user" ? "text-white" : "text-foreground"
                      )}>
                        {text}
                      </p>
                    </CardContent>
                  </Card>
                  {/* Assistant message actions */}
                  {message.role === "assistant" && (
                    <div className="flex items-center gap-2 mt-1.5 ml-1">
                      <CopyButton text={text} />
                      <button
                        type="button"
                        onClick={() => handleLike(message.id)}
                        className="p-1 rounded hover:bg-secondary transition-colors"
                        title="Útil"
                      >
                        <ThumbsUp className={cn(
                          "w-3.5 h-3.5",
                          likedMessages.has(message.id) ? "text-cyan-500 fill-cyan-500" : "text-muted-foreground"
                        )} />
                      </button>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <BookOpen className="w-3 h-3" />
                        Fonte: Livros Cavagnolli
                      </span>
                    </div>
                  )}
                </div>
                {message.role === "user" && (
                  <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0 mt-1">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            )
          })}
          
          {isLoading && messages[messages.length - 1]?.role !== "assistant" && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4 text-cyan-500" />
              </div>
              <Card className="bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 rounded-full bg-cyan-500 animate-bounce" style={{ animationDelay: "0ms" }} />
                      <div className="w-2 h-2 rounded-full bg-cyan-500 animate-bounce" style={{ animationDelay: "150ms" }} />
                      <div className="w-2 h-2 rounded-full bg-cyan-500 animate-bounce" style={{ animationDelay: "300ms" }} />
                    </div>
                    <span className="text-sm text-muted-foreground">Buscando nos livros...</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Suggested follow-ups after 2+ messages */}
          {messages.length >= 2 && !isLoading && messages[messages.length - 1]?.role === "assistant" && (
            <div className="flex flex-wrap gap-2 pl-11">
              {suggestedFollowUps
                .filter(() => Math.random() > 0.4)
                .slice(0, 2)
                .map((suggestion) => (
                  <button
                    type="button"
                    key={suggestion}
                    onClick={() => handleSend(suggestion)}
                    className="text-xs px-3 py-1.5 rounded-full border border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10 transition-colors"
                  >
                    {suggestion}
                  </button>
                ))}
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      )}

      {/* Input */}
      <div className="border-t border-border bg-card/95 backdrop-blur-sm sticky bottom-16 md:bottom-0">
        <div className="container mx-auto px-4 py-3">
          <form onSubmit={handleSubmit} className="flex gap-3">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Pergunte sobre treino, nutrição, periodização..."
              className="flex-1 bg-secondary border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/50 placeholder:text-muted-foreground text-foreground"
              disabled={isLoading}
            />
            <Button 
              type="submit" 
              size="icon" 
              className="h-12 w-12 rounded-xl bg-cyan-600 hover:bg-cyan-700"
              disabled={!inputValue.trim() || isLoading}
            >
              <Send className="w-5 h-5" />
            </Button>
          </form>
          {messages.length > 0 && (
            <p className="text-xs text-muted-foreground text-center mt-2">
              A IA pode cometer erros. Sempre consulte um profissional.
            </p>
          )}
        </div>
      </div>
    </div>
  )
}
