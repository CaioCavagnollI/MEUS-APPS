"use client"

import { useState } from "react"
import {
  TrendingUp,
  DollarSign,
  Users,
  BookOpen,
  MessageCircle,
  Eye,
  ArrowUpRight,
  ArrowDownRight,
  ChevronRight,
  BarChart3,
} from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  AreaChart,
  Area,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from "recharts"

// Revenue data
const revenueData = [
  { month: "Set", receita: 4200 },
  { month: "Out", receita: 5800 },
  { month: "Nov", receita: 7100 },
  { month: "Dez", receita: 9400 },
  { month: "Jan", receita: 8200 },
  { month: "Fev", receita: 11500 },
  { month: "Mar", receita: 13800 },
]

// Book sales data
const bookSalesData = [
  { name: "Periodização", vendas: 234 },
  { name: "Biomecânica", vendas: 189 },
  { name: "Hipertrofia", vendas: 156 },
  { name: "Força", vendas: 142 },
  { name: "Box (9 livros)", vendas: 312 },
]

// AI usage data
const aiUsageData = [
  { day: "Seg", perguntas: 45 },
  { day: "Ter", perguntas: 62 },
  { day: "Qua", perguntas: 58 },
  { day: "Qui", perguntas: 71 },
  { day: "Sex", perguntas: 53 },
  { day: "Sáb", perguntas: 38 },
  { day: "Dom", perguntas: 29 },
]

// Category distribution
const categoryData = [
  { name: "Treinamento", value: 40 },
  { name: "Biomecânica", value: 25 },
  { name: "Nutrição", value: 20 },
  { name: "Recuperação", value: 15 },
]

const COLORS = ["#06b6d4", "#10b981", "#f59e0b", "#8b5cf6"]

interface AnalyticsDashboardProps {
  onBack: () => void
}

export function AnalyticsDashboard({ onBack }: AnalyticsDashboardProps) {
  const [period, setPeriod] = useState<"7d" | "30d" | "90d">("30d")

  return (
    <div className="min-h-screen">
      <section className="container mx-auto px-4 py-8">
        <Button variant="ghost" onClick={onBack} className="gap-2 -ml-2 mb-4">
          <ChevronRight className="h-4 w-4 rotate-180" />
          Voltar
        </Button>

        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <BarChart3 className="w-6 h-6 text-cyan-500" />
            <h1 className="text-2xl font-bold text-foreground">Analytics</h1>
          </div>
          <div className="flex gap-1 bg-secondary rounded-lg p-1">
            {(["7d", "30d", "90d"] as const).map((p) => (
              <button
                type="button"
                key={p}
                onClick={() => setPeriod(p)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                  period === p
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {p === "7d" ? "7 dias" : p === "30d" ? "30 dias" : "90 dias"}
              </button>
            ))}
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <DollarSign className="w-5 h-5 text-green-500" />
                <Badge className="bg-green-500/10 text-green-500 border-green-500/20 text-xs gap-0.5">
                  <ArrowUpRight className="w-3 h-3" />
                  24%
                </Badge>
              </div>
              <div className="text-2xl font-bold text-foreground">R$ 13.8k</div>
              <div className="text-xs text-muted-foreground">Receita total</div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Users className="w-5 h-5 text-cyan-500" />
                <Badge className="bg-cyan-500/10 text-cyan-500 border-cyan-500/20 text-xs gap-0.5">
                  <ArrowUpRight className="w-3 h-3" />
                  18%
                </Badge>
              </div>
              <div className="text-2xl font-bold text-foreground">1.247</div>
              <div className="text-xs text-muted-foreground">Usuários ativos</div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <BookOpen className="w-5 h-5 text-yellow-500" />
                <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20 text-xs gap-0.5">
                  <ArrowUpRight className="w-3 h-3" />
                  31%
                </Badge>
              </div>
              <div className="text-2xl font-bold text-foreground">1.033</div>
              <div className="text-xs text-muted-foreground">Livros vendidos</div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <MessageCircle className="w-5 h-5 text-purple-500" />
                <Badge className="bg-red-500/10 text-red-500 border-red-500/20 text-xs gap-0.5">
                  <ArrowDownRight className="w-3 h-3" />
                  5%
                </Badge>
              </div>
              <div className="text-2xl font-bold text-foreground">356</div>
              <div className="text-xs text-muted-foreground">Perguntas IA (semana)</div>
            </CardContent>
          </Card>
        </div>

        {/* Revenue Chart */}
        <Card className="bg-card border-border mb-6">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold text-foreground">Receita Mensal</h3>
                <p className="text-xs text-muted-foreground">Últimos 7 meses</p>
              </div>
              <Badge className="bg-green-500/10 text-green-500 border-green-500/20 gap-0.5">
                <TrendingUp className="w-3 h-3" />
                +228%
              </Badge>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={revenueData}>
                  <defs>
                    <linearGradient id="colorReceita" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="month" tick={{ fill: "#94a3b8", fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "#94a3b8", fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={(v) => `R$${v / 1000}k`} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #334155", borderRadius: "8px" }}
                    labelStyle={{ color: "#94a3b8" }}
                    formatter={(value: number) => [`R$ ${value.toLocaleString("pt-BR")}`, "Receita"]}
                  />
                  <Area type="monotone" dataKey="receita" stroke="#06b6d4" strokeWidth={2} fill="url(#colorReceita)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6 mb-6">
          {/* Book Sales */}
          <Card className="bg-card border-border">
            <CardContent className="p-4 md:p-6">
              <h3 className="font-semibold text-foreground mb-1">Vendas por Livro</h3>
              <p className="text-xs text-muted-foreground mb-4">Top 5 mais vendidos</p>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={bookSalesData} layout="vertical" barSize={16}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" horizontal={false} />
                    <XAxis type="number" tick={{ fill: "#94a3b8", fontSize: 12 }} axisLine={false} tickLine={false} />
                    <YAxis type="category" dataKey="name" tick={{ fill: "#94a3b8", fontSize: 11 }} axisLine={false} tickLine={false} width={90} />
                    <Tooltip
                      contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #334155", borderRadius: "8px" }}
                      labelStyle={{ color: "#94a3b8" }}
                    />
                    <Bar dataKey="vendas" fill="#06b6d4" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Category Distribution */}
          <Card className="bg-card border-border">
            <CardContent className="p-4 md:p-6">
              <h3 className="font-semibold text-foreground mb-1">Temas Mais Consultados</h3>
              <p className="text-xs text-muted-foreground mb-4">Distribuição por categoria na IA</p>
              <div className="h-56 flex items-center">
                <div className="w-1/2">
                  <ResponsiveContainer width="100%" height={180}>
                    <PieChart>
                      <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={70}
                        paddingAngle={4}
                        dataKey="value"
                      >
                        {categoryData.map((_, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="w-1/2 space-y-3">
                  {categoryData.map((item, index) => (
                    <div key={item.name} className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: COLORS[index] }} />
                      <span className="text-xs text-muted-foreground flex-1">{item.name}</span>
                      <span className="text-xs font-medium text-foreground">{item.value}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* AI Usage Chart */}
        <Card className="bg-card border-border mb-6 pb-24 md:pb-0">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold text-foreground">Uso do AI Mentor</h3>
                <p className="text-xs text-muted-foreground">Perguntas por dia (última semana)</p>
              </div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Eye className="w-3.5 h-3.5" />
                356 total
              </div>
            </div>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={aiUsageData} barSize={24}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="day" tick={{ fill: "#94a3b8", fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "#94a3b8", fontSize: 12 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #334155", borderRadius: "8px" }}
                    labelStyle={{ color: "#94a3b8" }}
                  />
                  <Bar dataKey="perguntas" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
