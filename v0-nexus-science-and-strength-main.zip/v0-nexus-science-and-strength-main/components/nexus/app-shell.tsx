"use client"

import { useState, type ReactNode } from "react"
import { Home, BookOpen, MessageCircle, Users, User, Bell, Dumbbell, ClipboardList } from "lucide-react"
import { cn } from "@/lib/utils"
import { NotificationsPanel } from "./notifications-panel"

type Tab = "home" | "library" | "ai" | "lab" | "profile" | "anamnese" | "workout"

interface AppShellProps {
  children?: ReactNode
  activeTab: Tab
  onTabChange: (tab: Tab) => void
}

const navItems = [
  { id: "home" as Tab, label: "Home", icon: Home },
  { id: "library" as Tab, label: "Library", icon: BookOpen },
  { id: "ai" as Tab, label: "AI Mentor", icon: MessageCircle },
  { id: "lab" as Tab, label: "Nexus Lab", icon: Users },
  { id: "profile" as Tab, label: "Perfil", icon: User },
]

const mobileNavItems = [
  { id: "home" as Tab, label: "Home", icon: Home },
  { id: "library" as Tab, label: "Livros", icon: BookOpen },
  { id: "ai" as Tab, label: "IA", icon: MessageCircle },
  { id: "lab" as Tab, label: "Lab", icon: Users },
  { id: "profile" as Tab, label: "Perfil", icon: User },
]

export function AppShell({ children, activeTab, onTabChange }: AppShellProps) {
  const [showNotifications, setShowNotifications] = useState(false)

  return (
    <div className="min-h-screen flex flex-col">
      {/* Desktop Header */}
      <header className="hidden md:flex fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#d4a017] flex items-center justify-center">
              <span className="font-bold text-black text-sm">N</span>
            </div>
            <span className="font-bold text-xl text-foreground tracking-tight">NEXUS</span>
            <span className="text-xs text-muted-foreground hidden lg:inline ml-1 tracking-widest uppercase">Science & Strength</span>
          </div>
          <nav className="flex items-center gap-1">
            {navItems.map((item) => (
              <button
                type="button"
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={cn(
                  "px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2",
                  activeTab === item.id
                    ? "bg-[#d4a017] text-black"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                )}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </button>
            ))}
            {/* Extra nav items */}
            <button
              type="button"
              onClick={() => onTabChange("anamnese")}
              className={cn(
                "px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2",
                activeTab === "anamnese"
                  ? "bg-[#d4a017] text-black"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary"
              )}
            >
              <ClipboardList className="w-4 h-4" />
              Anamnese
            </button>
            <button
              type="button"
              onClick={() => onTabChange("workout")}
              className={cn(
                "px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2",
                activeTab === "workout"
                  ? "bg-[#d4a017] text-black"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary"
              )}
            >
              <Dumbbell className="w-4 h-4" />
              Treino
            </button>
          </nav>
          <button
            type="button"
            onClick={() => setShowNotifications(true)}
            className="relative p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#d4a017]" />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 pt-0 md:pt-16 pb-20 md:pb-0">
        {children}
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-card/95 backdrop-blur-sm border-t border-border">
        <div className="flex items-center justify-around h-16 px-2">
          {mobileNavItems.map((item) => (
            <button
              type="button"
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={cn(
                "flex flex-col items-center justify-center gap-1 flex-1 py-2 rounded-lg transition-colors",
                activeTab === item.id
                  ? "text-[#d4a017]"
                  : "text-muted-foreground"
              )}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* Notifications Panel */}
      {showNotifications && (
        <NotificationsPanel onClose={() => setShowNotifications(false)} />
      )}
    </div>
  )
}
