"use client"

import { Heart, MessageSquare, Share2, Bookmark, ChevronRight, Trophy, Dumbbell, Flame, BookOpen, Star, TrendingUp, Sparkles, Zap, ClipboardList, ScanLine } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import useSWR from "swr"
import { createClient } from "@/lib/supabase/client"

const feedPosts = [
  {
    id: 1,
    author: "Caio Cavagnolli",
    avatar: "/placeholder-user.jpg",
    role: "Mestre em Desempenho Funcional, UnB",
    title: "Mito da Falha Concentrica",
    content: "A crenca de que treinar ate a falha concentrica e necessario para hipertrofia e um dos maiores equivocos da cultura fitness. Estudos mostram que parar 1-3 repeticoes antes da falha gera adaptacoes similares com menor fadiga acumulada.",
    likes: 847,
    comments: 56,
    category: "Fisiologia",
    timeAgo: "2h",
  },
  {
    id: 2,
    author: "Caio Cavagnolli",
    avatar: "/placeholder-user.jpg",
    role: "Mestre em Desempenho Funcional, UnB",
    title: "Biomecanica do Agachamento",
    content: "O joelho pode SIM ultrapassar a ponta do pe. A limitacao dessa amplitude forca compensacoes na coluna lombar. O que importa e a distribuicao da carga entre quadril e joelho.",
    likes: 1203,
    comments: 89,
    category: "Biomecanica",
    timeAgo: "5h",
  },
  {
    id: 3,
    author: "Caio Cavagnolli",
    avatar: "/placeholder-user.jpg",
    role: "Mestre em Desempenho Funcional, UnB",
    title: "Periodizacao Ondulada",
    content: "A periodizacao ondulada diaria (DUP) permite variacao de intensidade e volume dentro da mesma semana, otimizando as adaptacoes neurais e estruturais sem gerar monotonia no treinamento.",
    likes: 634,
    comments: 42,
    category: "Periodizacao",
    timeAgo: "8h",
  },
]

const categoryBadgeColors: Record<string, string> = {
  "Fisiologia": "border-[#d4a017]/30 text-[#d4a017]",
  "Biomecanica": "border-white/30 text-white",
  "Periodizacao": "border-[#f5d060]/30 text-[#f5d060]",
}

const fetcher = async () => {
  const supabase = createClient()
  const { data } = await supabase
    .from("books")
    .select("id, title, price, category")
    .eq("is_bundle", false)
    .limit(3)
  return data || []
}

export function HomePage() {
  const { data: topBooks } = useSWR("top-books-home", fetcher)

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#d4a017]/5 via-background to-background" />
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#d4a017]/5 rounded-full blur-3xl" />
        <div className="container mx-auto px-4 py-16 md:py-24 relative">
          <div className="max-w-3xl mx-auto text-center">
            <Badge className="mb-6 bg-[#d4a017]/10 text-[#d4a017] border-[#d4a017]/20 hover:bg-[#d4a017]/20 px-4 py-1.5">
              <Sparkles className="w-3.5 h-3.5 mr-1.5" />
              Metodologia Cientifica
            </Badge>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 text-balance text-foreground leading-tight">
              Science Applied to{" "}
              <span className="text-[#d4a017]">Strength</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-10 text-pretty max-w-xl mx-auto">
              A metodologia do Best-Seller Caio Cavagnolli. Treinamento baseado em evidencias cientificas.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-[#d4a017] hover:bg-[#b8860b] text-black font-semibold px-8">
                <Dumbbell className="w-5 h-5 mr-2" />
                Comecar Agora
              </Button>
              <Button size="lg" variant="outline" className="border-[#d4a017]/30 text-[#d4a017] hover:bg-[#d4a017]/10 bg-transparent">
                Conhecer Metodologia
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="border-y border-border bg-card/50">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl md:text-3xl font-bold text-[#d4a017]">9</div>
              <div className="text-sm text-muted-foreground">Livros Publicados</div>
            </div>
            <div>
              <div className="text-2xl md:text-3xl font-bold text-white">50K+</div>
              <div className="text-sm text-muted-foreground">Alunos</div>
            </div>
            <div>
              <div className="text-2xl md:text-3xl font-bold text-[#d4a017]">15+</div>
              <div className="text-sm text-muted-foreground">Anos de Pesquisa</div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Access Grid */}
      <section className="container mx-auto px-4 py-8">
        <h2 className="text-lg font-bold text-foreground mb-4">Acesso Rapido</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="bg-card border-border hover:border-[#d4a017]/30 transition-colors cursor-pointer group">
            <CardContent className="p-4 text-center">
              <ClipboardList className="w-8 h-8 text-[#d4a017] mx-auto mb-2 group-hover:scale-110 transition-transform" />
              <p className="text-sm font-medium text-foreground">Anamnese</p>
              <p className="text-xs text-muted-foreground">Avaliacao inteligente</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border hover:border-[#d4a017]/30 transition-colors cursor-pointer group">
            <CardContent className="p-4 text-center">
              <Dumbbell className="w-8 h-8 text-[#d4a017] mx-auto mb-2 group-hover:scale-110 transition-transform" />
              <p className="text-sm font-medium text-foreground">Meu Treino</p>
              <p className="text-xs text-muted-foreground">Prescricao com IA</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border hover:border-[#d4a017]/30 transition-colors cursor-pointer group">
            <CardContent className="p-4 text-center">
              <ScanLine className="w-8 h-8 text-[#d4a017] mx-auto mb-2 group-hover:scale-110 transition-transform" />
              <p className="text-sm font-medium text-foreground">Scanner</p>
              <p className="text-xs text-muted-foreground">Identifique equipamentos</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border hover:border-[#d4a017]/30 transition-colors cursor-pointer group">
            <CardContent className="p-4 text-center">
              <BookOpen className="w-8 h-8 text-[#d4a017] mx-auto mb-2 group-hover:scale-110 transition-transform" />
              <p className="text-sm font-medium text-foreground">Biblioteca</p>
              <p className="text-xs text-muted-foreground">9 livros disponiveis</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Featured Books Row */}
      {topBooks && topBooks.length > 0 && (
        <section className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Star className="w-5 h-5 text-[#d4a017] fill-[#d4a017]" />
              <h2 className="text-lg font-bold text-foreground">Destaque</h2>
            </div>
            <Badge variant="outline" className="text-xs border-[#d4a017]/30 text-[#d4a017]">
              <Zap className="w-3 h-3 mr-1" />
              Best-sellers
            </Badge>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-none">
            {topBooks.map((book) => (
              <Card key={book.id} className="bg-card border-border shrink-0 w-44 hover:border-[#d4a017]/30 transition-colors">
                <CardContent className="p-3">
                  <div className="aspect-[3/4] bg-gradient-to-br from-[#d4a017]/20 to-[#b8860b]/10 rounded-md flex items-center justify-center mb-2 border border-[#d4a017]/10">
                    <BookOpen className="w-8 h-8 text-[#d4a017]/60" />
                  </div>
                  <p className="text-xs font-medium text-foreground truncate">{book.title}</p>
                  <p className="text-xs text-[#d4a017] font-semibold">R$ {Number(book.price).toFixed(2)}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* Feed Section */}
      <section className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl md:text-2xl font-bold text-foreground">Conteudo Cientifico</h2>
          <Button variant="ghost" size="sm" className="text-[#d4a017] hover:text-[#f5d060]">
            Ver todos
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
        
        <div className="space-y-4">
          {feedPosts.map((post) => (
            <Card key={post.id} className="bg-card border-border overflow-hidden hover:border-[#d4a017]/20 transition-colors">
              <CardContent className="p-4 md:p-6">
                <div className="flex items-start gap-3 mb-4">
                  <Avatar className="w-10 h-10 md:w-12 md:h-12 border-2 border-[#d4a017]/20">
                    <AvatarImage src={post.avatar || "/placeholder.svg"} alt={post.author} />
                    <AvatarFallback className="bg-[#d4a017]/10 text-[#d4a017]">
                      {post.author.split(" ").map(n => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold text-foreground">{post.author}</h3>
                      <Badge variant="secondary" className="text-xs bg-[#d4a017]/10 text-[#d4a017] border-[#d4a017]/20">
                        Autor
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground truncate">{post.role}</p>
                  </div>
                  <span className="text-xs text-muted-foreground">{post.timeAgo}</span>
                </div>

                <div className="mb-4">
                  <Badge variant="outline" className={`text-xs mb-2 ${categoryBadgeColors[post.category] || "border-[#d4a017]/30 text-[#d4a017]"}`}>
                    {post.category}
                  </Badge>
                  <h4 className="font-semibold text-lg mb-2 text-foreground">{post.title}</h4>
                  <p className="text-muted-foreground leading-relaxed">{post.content}</p>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <div className="flex items-center gap-4">
                    <button type="button" className="flex items-center gap-1.5 text-muted-foreground hover:text-red-400 transition-colors">
                      <Heart className="w-5 h-5" />
                      <span className="text-sm">{post.likes}</span>
                    </button>
                    <button type="button" className="flex items-center gap-1.5 text-muted-foreground hover:text-[#d4a017] transition-colors">
                      <MessageSquare className="w-5 h-5" />
                      <span className="text-sm">{post.comments}</span>
                    </button>
                    <button type="button" className="flex items-center gap-1.5 text-muted-foreground hover:text-[#d4a017] transition-colors">
                      <Share2 className="w-5 h-5" />
                    </button>
                  </div>
                  <button type="button" className="text-muted-foreground hover:text-[#d4a017] transition-colors">
                    <Bookmark className="w-5 h-5" />
                  </button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Ambassadors Section */}
      <section className="container mx-auto px-4 py-8 pb-24 md:pb-8">
        <Card className="bg-card border-[#d4a017]/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Trophy className="w-5 h-5 text-[#d4a017]" />
              <h2 className="text-xl font-bold text-foreground">Embaixadores Nexus</h2>
            </div>
            <p className="text-muted-foreground mb-6">
              Junte-se ao time de treinadores Nexus e faca parte da comunidade cientifica.
            </p>
            <div className="flex items-center gap-4 mb-6">
              <div className="flex -space-x-3">
                {[1, 2, 3].map((i) => (
                  <Avatar key={i} className="w-10 h-10 border-2 border-card">
                    <AvatarFallback className="bg-[#d4a017]/10 text-[#d4a017] text-xs">
                      {["JS", "MS", "PC"][i - 1]}
                    </AvatarFallback>
                  </Avatar>
                ))}
                <div className="w-10 h-10 rounded-full bg-[#d4a017]/10 border-2 border-card flex items-center justify-center">
                  <span className="text-xs text-[#d4a017] font-medium">+47</span>
                </div>
              </div>
              <span className="text-sm text-muted-foreground">50 treinadores certificados</span>
            </div>
            <Button className="w-full bg-[#d4a017] hover:bg-[#b8860b] text-black font-semibold">
              <TrendingUp className="w-4 h-4 mr-2" />
              Tornar-se Embaixador
            </Button>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
