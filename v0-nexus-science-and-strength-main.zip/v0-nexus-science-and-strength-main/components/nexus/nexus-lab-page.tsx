"use client"

import { Crown, Star, Check, Users, Award, Zap, MessageCircle, Lock, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import useSWR from "swr"
import { createClient } from "@/lib/supabase/client"

interface Trainer {
  id: string
  name: string
  specialty: string
  bio: string | null
  avatar_url: string | null
  rating: number
  review_count: number
  price_monthly_cents: number
  is_vip: boolean
  certifications: string[]
}

const vipPlan = {
  title: "Consultoria Cavagnolli Black",
  price: 497,
  period: "mês",
  features: [
    "Mentoria direta com o autor",
    "Acesso a todos os livros",
    "Treinos personalizados mensais",
    "Avaliação física completa",
    "Grupo VIP exclusivo",
    "Suporte prioritário 24/7",
  ],
}

const trainersFetcher = async () => {
  const supabase = createClient()
  const { data, error } = await supabase
    .from("trainers")
    .select("*")
    .order("rating", { ascending: false })
  if (error) throw error
  return data as Trainer[]
}

export function NexusLabPage() {
  const { data: trainers, isLoading } = useSWR("trainers", trainersFetcher)

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-2">
          <Users className="w-6 h-6 text-cyan-500" />
          <h1 className="text-2xl md:text-3xl font-bold text-foreground">Nexus Lab</h1>
        </div>
        <p className="text-muted-foreground">Consultoria e treinamento com profissionais certificados</p>
      </section>

      {/* VIP Plan */}
      <section className="container mx-auto px-4 pb-8">
        <Card className="bg-gradient-to-br from-yellow-500/10 via-card to-card border-yellow-500/30 overflow-hidden relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/5 rounded-full blur-3xl" />
          
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <Badge className="bg-yellow-500 text-black font-semibold">
                <Crown className="w-3 h-3 mr-1" />
                VIP
              </Badge>
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                ))}
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="relative">
            <h2 className="text-2xl md:text-3xl font-bold mb-2 text-foreground">{vipPlan.title}</h2>
            <div className="flex items-baseline gap-1 mb-6">
              <span className="text-4xl md:text-5xl font-bold text-yellow-500">R$ {vipPlan.price}</span>
              <span className="text-muted-foreground">/{vipPlan.period}</span>
            </div>

            <div className="grid gap-3 mb-6">
              {vipPlan.features.map((feature, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-yellow-500/20 flex items-center justify-center shrink-0">
                    <Check className="w-3 h-3 text-yellow-500" />
                  </div>
                  <span className="text-sm text-foreground">{feature}</span>
                </div>
              ))}
            </div>

            <Button size="lg" className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-semibold">
              <Lock className="w-4 h-4 mr-2" />
              Assinar Plano VIP
            </Button>
          </CardContent>
        </Card>
      </section>

      {/* Trainers Marketplace */}
      <section className="container mx-auto px-4 pb-8">
        <h2 className="text-xl font-bold mb-6 text-foreground">Treinadores Certificados</h2>
        
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 animate-spin text-cyan-500" />
          </div>
        ) : (
          <div className="space-y-4">
            {(trainers || []).map((trainer) => (
              <Card key={trainer.id} className="bg-card border-border overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <Avatar className="w-16 h-16 md:w-20 md:h-20">
                      <AvatarImage src={trainer.avatar_url || "/placeholder.svg"} alt={trainer.name} />
                      <AvatarFallback className="bg-cyan-500/20 text-cyan-500 text-lg">
                        {trainer.name.split(" ").map(n => n[0]).join("")}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <div>
                          <h3 className="font-semibold text-lg text-foreground">{trainer.name}</h3>
                          <p className="text-sm text-muted-foreground">{trainer.specialty}</p>
                        </div>
                        {trainer.is_vip && (
                          <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
                            <Crown className="w-3 h-3 mr-1" />
                            VIP
                          </Badge>
                        )}
                      </div>

                      <div className="flex items-center gap-4 mb-3">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                          <span className="text-sm font-medium text-foreground">{Number(trainer.rating).toFixed(1)}</span>
                          <span className="text-xs text-muted-foreground">({trainer.review_count})</span>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2 mb-4">
                        {(Array.isArray(trainer.certifications) ? trainer.certifications : []).slice(0, 3).map((cert, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs border-cyan-500/30 text-cyan-500">
                            <Award className="w-3 h-3 mr-1" />
                            {cert}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-2xl font-bold text-cyan-500">
                            R$ {(trainer.price_monthly_cents / 100).toFixed(2).replace(".", ",")}
                          </span>
                          <span className="text-sm text-muted-foreground">/mês</span>
                        </div>
                        <Button className="bg-cyan-600 hover:bg-cyan-700 text-white">
                          <MessageCircle className="w-4 h-4 mr-2" />
                          Contratar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>

      {/* CTA for Professionals */}
      <section className="container mx-auto px-4 pb-24 md:pb-8">
        <Card className="bg-gradient-to-br from-cyan-500/10 via-card to-card border-cyan-500/30">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-5 h-5 text-cyan-500" />
              <span className="text-sm font-medium text-cyan-500">Para Profissionais</span>
            </div>
            <h2 className="text-xl md:text-2xl font-bold mb-3 text-foreground">É Personal Trainer?</h2>
            <p className="text-muted-foreground mb-6">
              Crie seu Consultório Digital aqui e pague <span className="text-cyan-500 font-semibold">apenas se vender</span>. 
              Sem taxas fixas, sem burocracia.
            </p>
            
            <div className="grid grid-cols-3 gap-4 mb-6 text-center">
              <div>
                <div className="text-2xl font-bold text-cyan-500">0%</div>
                <div className="text-xs text-muted-foreground">Taxa fixa</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-yellow-500">85%</div>
                <div className="text-xs text-muted-foreground">Para você</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-cyan-500">24h</div>
                <div className="text-xs text-muted-foreground">Aprovação</div>
              </div>
            </div>

            <Button className="w-full bg-cyan-600 hover:bg-cyan-700 text-white">
              Criar Perfil de Treinador
            </Button>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
