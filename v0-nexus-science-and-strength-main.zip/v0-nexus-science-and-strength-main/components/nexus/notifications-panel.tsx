"use client"

import { useState } from "react"
import { Bell, BookOpen, ShoppingCart, MessageCircle, Star, Crown, X, Check } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface Notification {
  id: string
  type: "book" | "purchase" | "ai" | "review" | "vip" | "system"
  title: string
  message: string
  time: string
  read: boolean
}

const mockNotifications: Notification[] = [
  {
    id: "1",
    type: "book",
    title: "Novo livro disponível",
    message: "\"Periodização Avançada\" acabou de ser publicado na Nexus Publishing.",
    time: "2 min",
    read: false,
  },
  {
    id: "2",
    type: "vip",
    title: "Oferta VIP exclusiva",
    message: "Assine o plano Consultoria Black com 20% de desconto esta semana.",
    time: "1h",
    read: false,
  },
  {
    id: "3",
    type: "ai",
    title: "Nova funcionalidade no AI Mentor",
    message: "Agora a IA busca nos livros automaticamente para respostas mais precisas.",
    time: "3h",
    read: false,
  },
  {
    id: "4",
    type: "review",
    title: "Sua avaliação foi publicada",
    message: "Obrigado por avaliar \"Biomecânica Aplicada\". Sua opinião ajuda outros leitores!",
    time: "1d",
    read: true,
  },
  {
    id: "5",
    type: "purchase",
    title: "Compra confirmada",
    message: "Box Caio Cavagnolli (9 livros) está disponível na sua biblioteca.",
    time: "2d",
    read: true,
  },
]

const iconMap = {
  book: BookOpen,
  purchase: ShoppingCart,
  ai: MessageCircle,
  review: Star,
  vip: Crown,
  system: Bell,
}

const colorMap = {
  book: "text-cyan-500 bg-cyan-500/10",
  purchase: "text-green-500 bg-green-500/10",
  ai: "text-purple-500 bg-purple-500/10",
  review: "text-yellow-500 bg-yellow-500/10",
  vip: "text-yellow-500 bg-yellow-500/10",
  system: "text-muted-foreground bg-secondary",
}

interface NotificationsPanelProps {
  onClose: () => void
}

export function NotificationsPanel({ onClose }: NotificationsPanelProps) {
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications)
  const unreadCount = notifications.filter((n) => !n.read).length

  const markAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    )
  }

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
  }

  return (
    <div className="fixed inset-0 z-[60] bg-black/50 backdrop-blur-sm" onClick={onClose}>
      <div
        className="absolute right-0 top-0 h-full w-full max-w-md bg-background border-l border-border shadow-xl overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-background/95 backdrop-blur-sm border-b border-border p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-foreground" />
            <h2 className="font-bold text-foreground">Notificações</h2>
            {unreadCount > 0 && (
              <Badge className="bg-cyan-500 text-white text-xs px-1.5 py-0">
                {unreadCount}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <Button variant="ghost" size="sm" onClick={markAllAsRead} className="text-xs text-muted-foreground">
                <Check className="w-3.5 h-3.5 mr-1" />
                Marcar todas
              </Button>
            )}
            <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="p-4 space-y-2">
          {notifications.length === 0 ? (
            <div className="text-center py-12">
              <Bell className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">Nenhuma notificação</p>
            </div>
          ) : (
            notifications.map((notification) => {
              const Icon = iconMap[notification.type]
              return (
                <Card
                  key={notification.id}
                  className={cn(
                    "transition-colors cursor-pointer",
                    notification.read
                      ? "bg-card/50 border-border/50"
                      : "bg-card border-cyan-500/20 hover:border-cyan-500/40"
                  )}
                  onClick={() => markAsRead(notification.id)}
                >
                  <CardContent className="p-3">
                    <div className="flex gap-3">
                      <div className={cn("w-9 h-9 rounded-full flex items-center justify-center shrink-0", colorMap[notification.type])}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <h3 className={cn("text-sm font-medium", !notification.read && "text-foreground")}>
                            {notification.title}
                          </h3>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className="text-xs text-muted-foreground">{notification.time}</span>
                            {!notification.read && (
                              <div className="w-2 h-2 rounded-full bg-cyan-500" />
                            )}
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                          {notification.message}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })
          )}
        </div>
      </div>
    </div>
  )
}
