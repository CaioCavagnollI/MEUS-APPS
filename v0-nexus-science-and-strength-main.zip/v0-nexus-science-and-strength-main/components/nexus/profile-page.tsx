"use client"

import { useState } from "react"
import { Settings, BookOpen, Dumbbell, Award, Bell, LogOut, ChevronRight, Crown, Calendar, Flame, Target, BarChart3, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { ReadingProgressView } from "./reading-progress"
import { AnalyticsDashboard } from "./analytics-dashboard"

const userStats = {
  workoutsThisWeek: 4,
  workoutsGoal: 5,
  streak: 12,
  booksOwned: 3,
  totalWorkouts: 156,
}

type ProfileView = "main" | "reading" | "analytics"

export function ProfilePage() {
  const [view, setView] = useState<ProfileView>("main")

  if (view === "reading") {
    return <ReadingProgressView onBack={() => setView("main")} />
  }

  if (view === "analytics") {
    return <AnalyticsDashboard onBack={() => setView("main")} />
  }

  const menuItems = [
    { icon: Dumbbell, label: "Meus Treinos", description: "Histórico e prescrições", badge: "12 treinos", action: undefined },
    { icon: BookOpen, label: "Progresso de Leitura", description: "Páginas lidas, bookmarks e notas", badge: "3 livros", action: () => setView("reading") },
    { icon: BarChart3, label: "Analytics", description: "Métricas de vendas e engajamento", badge: "Novo", action: () => setView("analytics") },
    { icon: Award, label: "Certificações", description: "Badges e conquistas", badge: undefined, action: undefined },
    { icon: Calendar, label: "Agenda", description: "Consultorias agendadas", badge: undefined, action: undefined },
    { icon: Bell, label: "Notificações", description: "Preferências de alertas", badge: undefined, action: undefined },
    { icon: Settings, label: "Configurações", description: "Conta e privacidade", badge: undefined, action: undefined },
  ]

  return (
    <div className="min-h-screen">
      {/* Profile Header */}
      <section className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center gap-6">
          <Avatar className="w-24 h-24 md:w-32 md:h-32 border-4 border-cyan-500/20">
            <AvatarImage src="/placeholder-user.jpg" alt="User" />
            <AvatarFallback className="bg-cyan-500/20 text-cyan-500 text-2xl">US</AvatarFallback>
          </Avatar>
          
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-2xl md:text-3xl font-bold text-foreground">Usuário Nexus</h1>
              <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
                <Crown className="w-3 h-3 mr-1" />
                Premium
              </Badge>
            </div>
            <p className="text-muted-foreground mb-4">usuario@email.com</p>
            <div className="flex gap-3">
              <Button variant="outline" size="sm" className="border-border hover:bg-secondary bg-transparent">
                <Settings className="w-4 h-4 mr-2" />
                Editar Perfil
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Cards */}
      <section className="container mx-auto px-4 pb-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <Flame className="w-6 h-6 text-orange-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-foreground">{userStats.streak}</div>
              <div className="text-xs text-muted-foreground">Dias seguidos</div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <Dumbbell className="w-6 h-6 text-cyan-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-foreground">{userStats.totalWorkouts}</div>
              <div className="text-xs text-muted-foreground">Total treinos</div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <BookOpen className="w-6 h-6 text-yellow-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-foreground">{userStats.booksOwned}</div>
              <div className="text-xs text-muted-foreground">Livros</div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <Award className="w-6 h-6 text-green-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-foreground">7</div>
              <div className="text-xs text-muted-foreground">Conquistas</div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Weekly Progress */}
      <section className="container mx-auto px-4 pb-6">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-cyan-500" />
                <span className="font-semibold text-foreground">Meta Semanal</span>
              </div>
              <span className="text-sm text-muted-foreground">
                {userStats.workoutsThisWeek}/{userStats.workoutsGoal} treinos
              </span>
            </div>
            <Progress 
              value={(userStats.workoutsThisWeek / userStats.workoutsGoal) * 100} 
              className="h-3 bg-secondary"
            />
            <p className="text-xs text-muted-foreground mt-2">
              Faltam {userStats.workoutsGoal - userStats.workoutsThisWeek} treinos para completar sua meta!
            </p>
          </CardContent>
        </Card>
      </section>

      {/* Quick Actions */}
      <section className="container mx-auto px-4 pb-4">
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setView("reading")}
            className="p-4 rounded-xl bg-cyan-500/10 border border-cyan-500/20 hover:border-cyan-500/40 transition-colors text-left"
          >
            <BookOpen className="w-5 h-5 text-cyan-500 mb-2" />
            <p className="font-medium text-sm text-foreground">Continuar Lendo</p>
            <p className="text-xs text-muted-foreground">3 livros em progresso</p>
          </button>
          <button
            type="button"
            onClick={() => setView("analytics")}
            className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/20 hover:border-purple-500/40 transition-colors text-left"
          >
            <TrendingUp className="w-5 h-5 text-purple-500 mb-2" />
            <p className="font-medium text-sm text-foreground">Ver Analytics</p>
            <p className="text-xs text-muted-foreground">Receita +24% este mês</p>
          </button>
        </div>
      </section>

      {/* Menu Items */}
      <section className="container mx-auto px-4 pb-6">
        <div className="space-y-2">
          {menuItems.map((item) => (
            <Card
              key={item.label}
              className="bg-card border-border hover:border-cyan-500/30 transition-colors cursor-pointer"
              onClick={item.action}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center shrink-0">
                    <item.icon className="w-5 h-5 text-cyan-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium text-foreground">{item.label}</h3>
                      {item.badge && (
                        <Badge variant="secondary" className={`text-xs ${item.badge === "Novo" ? "bg-cyan-500/10 text-cyan-500 border-cyan-500/20" : ""}`}>
                          {item.badge}
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Logout */}
      <section className="container mx-auto px-4 pb-24 md:pb-8">
        <Button 
          variant="outline" 
          className="w-full border-destructive/30 text-destructive hover:bg-destructive/10 hover:text-destructive bg-transparent"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Sair da Conta
        </Button>
      </section>
    </div>
  )
}
