"use client"

import { BookOpen, Clock, Bookmark, TrendingUp, ChevronRight } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"

interface ReadingBook {
  id: string
  title: string
  category: string
  currentPage: number
  totalPages: number
  lastRead: string
  bookmarkedPages: number[]
}

const myBooks: ReadingBook[] = [
  {
    id: "1",
    title: "Periodização Científica",
    category: "Periodização",
    currentPage: 87,
    totalPages: 240,
    lastRead: "Hoje",
    bookmarkedPages: [12, 45, 78, 87],
  },
  {
    id: "2",
    title: "Biomecânica Aplicada ao Treinamento",
    category: "Biomecânica",
    currentPage: 156,
    totalPages: 310,
    lastRead: "Ontem",
    bookmarkedPages: [23, 99, 156],
  },
  {
    id: "3",
    title: "Hipertrofia: Ciência e Prática",
    category: "Treinamento",
    currentPage: 45,
    totalPages: 280,
    lastRead: "3 dias atrás",
    bookmarkedPages: [10, 22],
  },
]

const categoryColors: Record<string, string> = {
  "Periodização": "from-cyan-600 to-cyan-800",
  "Biomecânica": "from-green-600 to-green-800",
  "Treinamento": "from-blue-600 to-blue-800",
  "Força": "from-red-600 to-red-800",
  "Nutrição": "from-orange-600 to-orange-800",
}

interface ReadingProgressViewProps {
  onBack: () => void
}

export function ReadingProgressView({ onBack }: ReadingProgressViewProps) {
  const totalPages = myBooks.reduce((s, b) => s + b.totalPages, 0)
  const readPages = myBooks.reduce((s, b) => s + b.currentPage, 0)
  const totalBookmarks = myBooks.reduce((s, b) => s + b.bookmarkedPages.length, 0)
  const avgProgress = myBooks.length > 0
    ? myBooks.reduce((s, b) => s + (b.currentPage / b.totalPages) * 100, 0) / myBooks.length
    : 0

  return (
    <div className="min-h-screen">
      <section className="container mx-auto px-4 py-8">
        <Button variant="ghost" onClick={onBack} className="gap-2 -ml-2 mb-4">
          <ChevronRight className="h-4 w-4 rotate-180" />
          Voltar ao Perfil
        </Button>

        <div className="flex items-center gap-3 mb-6">
          <BookOpen className="w-6 h-6 text-cyan-500" />
          <h1 className="text-2xl font-bold text-foreground">Progresso de Leitura</h1>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <BookOpen className="w-5 h-5 text-cyan-500 mx-auto mb-1.5" />
              <div className="text-2xl font-bold text-foreground">{myBooks.length}</div>
              <div className="text-xs text-muted-foreground">Livros</div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-5 h-5 text-green-500 mx-auto mb-1.5" />
              <div className="text-2xl font-bold text-foreground">{readPages}</div>
              <div className="text-xs text-muted-foreground">Páginas lidas</div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <Bookmark className="w-5 h-5 text-yellow-500 mx-auto mb-1.5" />
              <div className="text-2xl font-bold text-foreground">{totalBookmarks}</div>
              <div className="text-xs text-muted-foreground">Bookmarks</div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <Clock className="w-5 h-5 text-purple-500 mx-auto mb-1.5" />
              <div className="text-2xl font-bold text-foreground">{Math.round(readPages / 30)}h</div>
              <div className="text-xs text-muted-foreground">Tempo lido</div>
            </CardContent>
          </Card>
        </div>

        {/* Overall Progress */}
        <Card className="bg-card border-border mb-8">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">Progresso Geral</span>
              <span className="text-sm text-cyan-500 font-medium">{Math.round(avgProgress)}%</span>
            </div>
            <Progress value={avgProgress} className="h-3" />
            <p className="text-xs text-muted-foreground mt-2">
              {readPages} de {totalPages} páginas totais
            </p>
          </CardContent>
        </Card>

        {/* Individual Books */}
        <h2 className="text-lg font-semibold text-foreground mb-4">Meus Livros</h2>
        <div className="space-y-4 pb-24 md:pb-8">
          {myBooks.map((book) => {
            const progress = (book.currentPage / book.totalPages) * 100
            const gradient = categoryColors[book.category] || "from-slate-600 to-slate-800"

            return (
              <Card key={book.id} className="bg-card border-border overflow-hidden">
                <CardContent className="p-0">
                  <div className="flex">
                    {/* Mini cover */}
                    <div className={`w-20 md:w-24 bg-gradient-to-br ${gradient} flex items-center justify-center shrink-0`}>
                      <BookOpen className="w-8 h-8 text-white/60" />
                    </div>
                    <div className="flex-1 p-4">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h3 className="font-semibold text-foreground text-sm">{book.title}</h3>
                        <Badge variant="outline" className="text-xs shrink-0 border-cyan-500/30 text-cyan-500">
                          {book.category}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mb-3">Lido pela última vez: {book.lastRead}</p>
                      
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xs text-muted-foreground">
                          Página {book.currentPage} de {book.totalPages}
                        </span>
                        <span className="text-xs font-medium text-cyan-500">{Math.round(progress)}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />

                      <div className="flex items-center gap-3 mt-3">
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Bookmark className="w-3 h-3 text-yellow-500" />
                          {book.bookmarkedPages.length} bookmarks
                        </span>
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          ~{Math.round(book.currentPage / 30)}h lidas
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </section>
    </div>
  )
}
