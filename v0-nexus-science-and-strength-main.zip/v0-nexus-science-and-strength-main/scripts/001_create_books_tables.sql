-- Enable pgvector extension for embeddings
CREATE EXTENSION IF NOT EXISTS vector;

-- Books table
CREATE TABLE IF NOT EXISTS books (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  subtitle TEXT,
  description TEXT,
  author TEXT NOT NULL DEFAULT 'Caio Cavagnolli',
  cover_url TEXT,
  price DECIMAL(10, 2) NOT NULL DEFAULT 0,
  original_price DECIMAL(10, 2),
  category TEXT DEFAULT 'Treinamento',
  is_featured BOOLEAN DEFAULT false,
  is_bundle BOOLEAN DEFAULT false,
  bundle_books TEXT[],
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Book chunks for RAG (vector search)
CREATE TABLE IF NOT EXISTS book_chunks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  chapter TEXT,
  page_number INTEGER,
  chunk_index INTEGER NOT NULL,
  embedding vector(1536),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for vector similarity search
CREATE INDEX IF NOT EXISTS book_chunks_embedding_idx ON book_chunks 
USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- Chat history for AI mentor
CREATE TABLE IF NOT EXISTS chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
  content TEXT NOT NULL,
  sources JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS chat_messages_session_idx ON chat_messages(session_id);

-- Enable RLS
ALTER TABLE books ENABLE ROW LEVEL SECURITY;
ALTER TABLE book_chunks ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

-- Public read access for books
CREATE POLICY "Books are publicly readable" ON books FOR SELECT USING (true);

-- Public read access for book chunks (for RAG)
CREATE POLICY "Book chunks are publicly readable" ON book_chunks FOR SELECT USING (true);

-- Anyone can create and read their own chat messages (by session_id)
CREATE POLICY "Chat messages are publicly readable" ON chat_messages FOR SELECT USING (true);
CREATE POLICY "Anyone can insert chat messages" ON chat_messages FOR INSERT WITH CHECK (true);

-- Insert sample books
INSERT INTO books (title, subtitle, description, author, price, original_price, category, is_featured, is_bundle, bundle_books) VALUES
(
  'Box Caio Cavagnolli',
  '9 Livros Completos',
  'Coleção completa com todos os 9 livros sobre treinamento de força, periodização e biomecânica. O pacote definitivo para quem quer dominar a ciência do treino.',
  'Caio Cavagnolli',
  497.00,
  1017.00,
  'Coleção',
  true,
  true,
  ARRAY['Periodização Científica', 'Biomecânica Aplicada', 'Hipertrofia Muscular', 'Força Máxima', 'Nutrição para Performance', 'Recuperação e Regeneração', 'Treinamento Avançado', 'Psicologia do Treino', 'Programação de Treino']
),
(
  'Periodização Científica',
  'Fundamentos e Aplicações Práticas',
  'O guia completo sobre periodização do treinamento. Aprenda a estruturar macrociclos, mesociclos e microciclos para maximizar seus resultados.',
  'Caio Cavagnolli',
  127.00,
  NULL,
  'Treinamento',
  false,
  false,
  NULL
),
(
  'Biomecânica Aplicada',
  'Ciência do Movimento Humano',
  'Entenda como os músculos, ossos e articulações trabalham juntos. Aprenda a otimizar cada exercício para máxima eficiência e segurança.',
  'Caio Cavagnolli',
  127.00,
  NULL,
  'Biomecânica',
  false,
  false,
  NULL
),
(
  'Hipertrofia Muscular',
  'A Ciência do Crescimento',
  'Tudo sobre os mecanismos de hipertrofia muscular. Tensão mecânica, estresse metabólico e dano muscular explicados de forma prática.',
  'Caio Cavagnolli',
  127.00,
  NULL,
  'Treinamento',
  false,
  false,
  NULL
),
(
  'Força Máxima',
  'Desenvolvimento de Força Absoluta',
  'Metodologias para desenvolvimento de força máxima. Desde os fundamentos neurais até programas avançados de powerlifting.',
  'Caio Cavagnolli',
  127.00,
  NULL,
  'Força',
  false,
  false,
  NULL
),
(
  'Nutrição para Performance',
  'Alimentação Estratégica',
  'Estratégias nutricionais para otimizar performance, recuperação e composição corporal. Baseado em evidências científicas atuais.',
  'Caio Cavagnolli',
  97.00,
  NULL,
  'Nutrição',
  false,
  false,
  NULL
),
(
  'Recuperação e Regeneração',
  'Otimize seu Descanso',
  'Sono, estresse e estratégias de recuperação. Aprenda como maximizar a supercompensação e evitar overtraining.',
  'Caio Cavagnolli',
  97.00,
  NULL,
  'Recuperação',
  false,
  false,
  NULL
),
(
  'Treinamento Avançado',
  'Técnicas para Atletas Experientes',
  'Métodos avançados de treinamento: drop sets, rest-pause, clusters, oclusão vascular e muito mais.',
  'Caio Cavagnolli',
  127.00,
  NULL,
  'Treinamento',
  false,
  false,
  NULL
),
(
  'Psicologia do Treino',
  'Mentalidade de Campeão',
  'Aspectos psicológicos do treinamento. Motivação, foco, gestão de expectativas e construção de hábitos.',
  'Caio Cavagnolli',
  87.00,
  NULL,
  'Psicologia',
  false,
  false,
  NULL
);
